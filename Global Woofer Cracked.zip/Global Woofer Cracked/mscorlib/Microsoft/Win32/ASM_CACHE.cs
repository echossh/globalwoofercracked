﻿using System;

namespace Microsoft.Win32
{
	// Token: 0x0200000A RID: 10
	internal static class ASM_CACHE
	{
		// Token: 0x04000052 RID: 82
		public const uint ZAP = 1U;

		// Token: 0x04000053 RID: 83
		public const uint GAC = 2U;

		// Token: 0x04000054 RID: 84
		public const uint DOWNLOAD = 4U;
	}
}
