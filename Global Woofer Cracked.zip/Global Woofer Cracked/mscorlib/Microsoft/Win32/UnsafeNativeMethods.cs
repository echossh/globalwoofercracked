﻿using System;
using System.Diagnostics.Tracing;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;

namespace Microsoft.Win32
{
	// Token: 0x02000018 RID: 24
	[SecurityCritical]
	[SuppressUnmanagedCodeSecurity]
	internal static class UnsafeNativeMethods
	{
		// Token: 0x0600014F RID: 335
		[DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
		internal static extern int GetTimeZoneInformation(out Win32Native.TimeZoneInformation lpTimeZoneInformation);

		// Token: 0x06000150 RID: 336
		[DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
		internal static extern int GetDynamicTimeZoneInformation(out Win32Native.DynamicTimeZoneInformation lpDynamicTimeZoneInformation);

		// Token: 0x06000151 RID: 337
		[DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		internal static extern bool GetFileMUIPath(int flags, [MarshalAs(UnmanagedType.LPWStr)] string filePath, [MarshalAs(UnmanagedType.LPWStr)] StringBuilder language, ref int languageLength, [MarshalAs(UnmanagedType.LPWStr)] StringBuilder fileMuiPath, ref int fileMuiPathLength, ref long enumerator);

		// Token: 0x06000152 RID: 338
		[DllImport("user32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Unicode, EntryPoint = "LoadStringW", ExactSpelling = true, SetLastError = true)]
		internal static extern int LoadString(SafeLibraryHandle handle, int id, StringBuilder buffer, int bufferLength);

		// Token: 0x06000153 RID: 339
		[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
		internal static extern SafeLibraryHandle LoadLibraryEx(string libFilename, IntPtr reserved, int flags);

		// Token: 0x06000154 RID: 340
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
		[DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
		[return: MarshalAs(UnmanagedType.Bool)]
		internal static extern bool FreeLibrary(IntPtr hModule);

		// Token: 0x06000155 RID: 341
		[SecurityCritical]
		[DllImport("combase.dll")]
		internal static extern int RoGetActivationFactory([MarshalAs(UnmanagedType.HString)] string activatableClassId, [In] ref Guid iid, [MarshalAs(UnmanagedType.IInspectable)] out object factory);

		// Token: 0x02000A91 RID: 2705
		[SecurityCritical]
		[SuppressUnmanagedCodeSecurity]
		internal static class ManifestEtw
		{
			// Token: 0x06006869 RID: 26729
			[SecurityCritical]
			[DllImport("advapi32.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
			internal unsafe static extern uint EventRegister([In] ref Guid providerId, [In] UnsafeNativeMethods.ManifestEtw.EtwEnableCallback enableCallback, [In] void* callbackContext, [In] [Out] ref long registrationHandle);

			// Token: 0x0600686A RID: 26730
			[SecurityCritical]
			[DllImport("advapi32.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
			internal static extern uint EventUnregister([In] long registrationHandle);

			// Token: 0x0600686B RID: 26731
			[SecurityCritical]
			[DllImport("advapi32.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
			internal unsafe static extern int EventWrite([In] long registrationHandle, [In] ref EventDescriptor eventDescriptor, [In] int userDataCount, [In] EventProvider.EventData* userData);

			// Token: 0x0600686C RID: 26732
			[SecurityCritical]
			[DllImport("advapi32.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
			internal static extern int EventWriteString([In] long registrationHandle, [In] byte level, [In] long keyword, [In] string msg);

			// Token: 0x0600686D RID: 26733 RVA: 0x00166E44 File Offset: 0x00165044
			internal unsafe static int EventWriteTransferWrapper(long registrationHandle, ref EventDescriptor eventDescriptor, Guid* activityId, Guid* relatedActivityId, int userDataCount, EventProvider.EventData* userData)
			{
				int num = UnsafeNativeMethods.ManifestEtw.EventWriteTransfer(registrationHandle, ref eventDescriptor, activityId, relatedActivityId, userDataCount, userData);
				if (num == 87 && relatedActivityId == null)
				{
					Guid empty = Guid.Empty;
					num = UnsafeNativeMethods.ManifestEtw.EventWriteTransfer(registrationHandle, ref eventDescriptor, activityId, &empty, userDataCount, userData);
				}
				return num;
			}

			// Token: 0x0600686E RID: 26734
			[SuppressUnmanagedCodeSecurity]
			[DllImport("advapi32.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
			private unsafe static extern int EventWriteTransfer([In] long registrationHandle, [In] ref EventDescriptor eventDescriptor, [In] Guid* activityId, [In] Guid* relatedActivityId, [In] int userDataCount, [In] EventProvider.EventData* userData);

			// Token: 0x0600686F RID: 26735
			[SuppressUnmanagedCodeSecurity]
			[DllImport("advapi32.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
			internal static extern int EventActivityIdControl([In] UnsafeNativeMethods.ManifestEtw.ActivityControl ControlCode, [In] [Out] ref Guid ActivityId);

			// Token: 0x06006870 RID: 26736
			[SuppressUnmanagedCodeSecurity]
			[DllImport("advapi32.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
			internal unsafe static extern int EventSetInformation([In] long registrationHandle, [In] UnsafeNativeMethods.ManifestEtw.EVENT_INFO_CLASS informationClass, [In] void* eventInformation, [In] int informationLength);

			// Token: 0x06006871 RID: 26737
			[SuppressUnmanagedCodeSecurity]
			[DllImport("advapi32.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
			internal unsafe static extern int EnumerateTraceGuidsEx(UnsafeNativeMethods.ManifestEtw.TRACE_QUERY_INFO_CLASS TraceQueryInfoClass, void* InBuffer, int InBufferSize, void* OutBuffer, int OutBufferSize, ref int ReturnLength);

			// Token: 0x04002FE4 RID: 12260
			internal const int ERROR_ARITHMETIC_OVERFLOW = 534;

			// Token: 0x04002FE5 RID: 12261
			internal const int ERROR_NOT_ENOUGH_MEMORY = 8;

			// Token: 0x04002FE6 RID: 12262
			internal const int ERROR_MORE_DATA = 234;

			// Token: 0x04002FE7 RID: 12263
			internal const int ERROR_NOT_SUPPORTED = 50;

			// Token: 0x04002FE8 RID: 12264
			internal const int ERROR_INVALID_PARAMETER = 87;

			// Token: 0x04002FE9 RID: 12265
			internal const int EVENT_CONTROL_CODE_DISABLE_PROVIDER = 0;

			// Token: 0x04002FEA RID: 12266
			internal const int EVENT_CONTROL_CODE_ENABLE_PROVIDER = 1;

			// Token: 0x04002FEB RID: 12267
			internal const int EVENT_CONTROL_CODE_CAPTURE_STATE = 2;

			// Token: 0x02000CB8 RID: 3256
			// (Invoke) Token: 0x06007090 RID: 28816
			[SecurityCritical]
			internal unsafe delegate void EtwEnableCallback([In] ref Guid sourceId, [In] int isEnabled, [In] byte level, [In] long matchAnyKeywords, [In] long matchAllKeywords, [In] UnsafeNativeMethods.ManifestEtw.EVENT_FILTER_DESCRIPTOR* filterData, [In] void* callbackContext);

			// Token: 0x02000CB9 RID: 3257
			internal struct EVENT_FILTER_DESCRIPTOR
			{
				// Token: 0x040037F9 RID: 14329
				public long Ptr;

				// Token: 0x040037FA RID: 14330
				public int Size;

				// Token: 0x040037FB RID: 14331
				public int Type;
			}

			// Token: 0x02000CBA RID: 3258
			internal enum ActivityControl : uint
			{
				// Token: 0x040037FD RID: 14333
				EVENT_ACTIVITY_CTRL_GET_ID = 1U,
				// Token: 0x040037FE RID: 14334
				EVENT_ACTIVITY_CTRL_SET_ID,
				// Token: 0x040037FF RID: 14335
				EVENT_ACTIVITY_CTRL_CREATE_ID,
				// Token: 0x04003800 RID: 14336
				EVENT_ACTIVITY_CTRL_GET_SET_ID,
				// Token: 0x04003801 RID: 14337
				EVENT_ACTIVITY_CTRL_CREATE_SET_ID
			}

			// Token: 0x02000CBB RID: 3259
			internal enum EVENT_INFO_CLASS
			{
				// Token: 0x04003803 RID: 14339
				BinaryTrackInfo,
				// Token: 0x04003804 RID: 14340
				SetEnableAllKeywords,
				// Token: 0x04003805 RID: 14341
				SetTraits
			}

			// Token: 0x02000CBC RID: 3260
			internal enum TRACE_QUERY_INFO_CLASS
			{
				// Token: 0x04003807 RID: 14343
				TraceGuidQueryList,
				// Token: 0x04003808 RID: 14344
				TraceGuidQueryInfo,
				// Token: 0x04003809 RID: 14345
				TraceGuidQueryProcess,
				// Token: 0x0400380A RID: 14346
				TraceStackTracingInfo,
				// Token: 0x0400380B RID: 14347
				MaxTraceSetInfoClass
			}

			// Token: 0x02000CBD RID: 3261
			internal struct TRACE_GUID_INFO
			{
				// Token: 0x0400380C RID: 14348
				public int InstanceCount;

				// Token: 0x0400380D RID: 14349
				public int Reserved;
			}

			// Token: 0x02000CBE RID: 3262
			internal struct TRACE_PROVIDER_INSTANCE_INFO
			{
				// Token: 0x0400380E RID: 14350
				public int NextOffset;

				// Token: 0x0400380F RID: 14351
				public int EnableCount;

				// Token: 0x04003810 RID: 14352
				public int Pid;

				// Token: 0x04003811 RID: 14353
				public int Flags;
			}

			// Token: 0x02000CBF RID: 3263
			internal struct TRACE_ENABLE_INFO
			{
				// Token: 0x04003812 RID: 14354
				public int IsEnabled;

				// Token: 0x04003813 RID: 14355
				public byte Level;

				// Token: 0x04003814 RID: 14356
				public byte Reserved1;

				// Token: 0x04003815 RID: 14357
				public ushort LoggerId;

				// Token: 0x04003816 RID: 14358
				public int EnableProperty;

				// Token: 0x04003817 RID: 14359
				public int Reserved2;

				// Token: 0x04003818 RID: 14360
				public long MatchAnyKeyword;

				// Token: 0x04003819 RID: 14361
				public long MatchAllKeyword;
			}
		}
	}
}
