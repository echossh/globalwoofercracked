﻿using System;

namespace Microsoft.Win32
{
	// Token: 0x0200000B RID: 11
	internal static class CANOF
	{
		// Token: 0x04000055 RID: 85
		public const uint PARSE_DISPLAY_NAME = 1U;

		// Token: 0x04000056 RID: 86
		public const uint SET_DEFAULT_VALUES = 2U;
	}
}
