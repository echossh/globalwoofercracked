﻿using System;

// Token: 0x02000004 RID: 4
internal static class FXAssembly
{
	// Token: 0x04000003 RID: 3
	internal const string Version = "4.0.0.0";
}
