﻿using System;
using System.Security;

namespace System.Diagnostics
{
	// Token: 0x020003B6 RID: 950
	internal class DefaultFilter : AssertFilter
	{
		// Token: 0x060031CF RID: 12751 RVA: 0x000C0063 File Offset: 0x000BE263
		internal DefaultFilter()
		{
		}

		// Token: 0x060031D0 RID: 12752 RVA: 0x000C006B File Offset: 0x000BE26B
		[SecuritySafeCritical]
		public override AssertFilters AssertFailure(string condition, string message, StackTrace location, StackTrace.TraceFormat stackTraceFormat, string windowTitle)
		{
			return (AssertFilters)Assert.ShowDefaultAssertDialog(condition, message, location.ToString(stackTraceFormat), windowTitle);
		}
	}
}
