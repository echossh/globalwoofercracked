﻿using System;
using System.Security.Permissions;

namespace System.Diagnostics
{
	// Token: 0x020003C5 RID: 965
	// (Invoke) Token: 0x0600320A RID: 12810
	[HostProtection(SecurityAction.LinkDemand, Synchronization = true, ExternalThreading = true)]
	[Serializable]
	internal delegate void LogMessageEventHandler(LoggingLevels level, LogSwitch category, string message, StackTrace location);
}
