﻿using System;
using System.Runtime.InteropServices;

namespace System.Diagnostics.SymbolStore
{
	/// <summary>Represents a lexical scope within <see cref="T:System.Diagnostics.SymbolStore.ISymbolMethod" />, providing access to the start and end offsets of the scope, as well as its child and parent scopes.</summary>
	// Token: 0x020003D5 RID: 981
	[ComVisible(true)]
	public interface ISymbolScope
	{
		/// <summary>Gets the method that contains the current lexical scope.</summary>
		/// <returns>The method that contains the current lexical scope.</returns>
		// Token: 0x1700077E RID: 1918
		// (get) Token: 0x06003294 RID: 12948
		ISymbolMethod Method { get; }

		/// <summary>Gets the parent lexical scope of the current scope.</summary>
		/// <returns>The parent lexical scope of the current scope.</returns>
		// Token: 0x1700077F RID: 1919
		// (get) Token: 0x06003295 RID: 12949
		ISymbolScope Parent { get; }

		/// <summary>Gets the child lexical scopes of the current lexical scope.</summary>
		/// <returns>The child lexical scopes that of the current lexical scope.</returns>
		// Token: 0x06003296 RID: 12950
		ISymbolScope[] GetChildren();

		/// <summary>Gets the start offset of the current lexical scope.</summary>
		/// <returns>The start offset of the current lexical scope.</returns>
		// Token: 0x17000780 RID: 1920
		// (get) Token: 0x06003297 RID: 12951
		int StartOffset { get; }

		/// <summary>Gets the end offset of the current lexical scope.</summary>
		/// <returns>The end offset of the current lexical scope.</returns>
		// Token: 0x17000781 RID: 1921
		// (get) Token: 0x06003298 RID: 12952
		int EndOffset { get; }

		/// <summary>Gets the local variables within the current lexical scope.</summary>
		/// <returns>The local variables within the current lexical scope.</returns>
		// Token: 0x06003299 RID: 12953
		ISymbolVariable[] GetLocals();

		/// <summary>Gets the namespaces that are used within the current scope.</summary>
		/// <returns>The namespaces that are used within the current scope.</returns>
		// Token: 0x0600329A RID: 12954
		ISymbolNamespace[] GetNamespaces();
	}
}
