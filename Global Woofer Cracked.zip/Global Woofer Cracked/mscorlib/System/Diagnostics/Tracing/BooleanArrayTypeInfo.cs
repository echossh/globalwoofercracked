﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000434 RID: 1076
	internal sealed class BooleanArrayTypeInfo : TraceLoggingTypeInfo<bool[]>
	{
		// Token: 0x06003567 RID: 13671 RVA: 0x000CEA05 File Offset: 0x000CCC05
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddArray(name, Statics.Format8(format, TraceLoggingDataType.Boolean8));
		}

		// Token: 0x06003568 RID: 13672 RVA: 0x000CEA19 File Offset: 0x000CCC19
		public override void WriteData(TraceLoggingDataCollector collector, ref bool[] value)
		{
			collector.AddArray(value);
		}
	}
}
