﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x020003FD RID: 1021
	internal enum EventChannelType
	{
		// Token: 0x040016EC RID: 5868
		Admin = 1,
		// Token: 0x040016ED RID: 5869
		Operational,
		// Token: 0x040016EE RID: 5870
		Analytic,
		// Token: 0x040016EF RID: 5871
		Debug
	}
}
