﻿using System;

namespace System.Diagnostics.Tracing
{
	/// <summary>Specifies additional event schema information for an event.</summary>
	// Token: 0x020003FA RID: 1018
	[AttributeUsage(AttributeTargets.Method)]
	[__DynamicallyInvokable]
	public sealed class EventAttribute : Attribute
	{
		/// <summary>Initializes a new instance of the <see cref="T:System.Diagnostics.Tracing.EventAttribute" /> class with the specified event identifier.</summary>
		/// <param name="eventId">The event identifier for the event.</param>
		// Token: 0x06003407 RID: 13319 RVA: 0x000C9C40 File Offset: 0x000C7E40
		[__DynamicallyInvokable]
		public EventAttribute(int eventId)
		{
			this.EventId = eventId;
			this.Level = EventLevel.Informational;
			this.m_opcodeSet = false;
		}

		/// <summary>Gets or sets the identifier for the event.</summary>
		/// <returns>The event identifier. This value should be between 0 and 65535.</returns>
		// Token: 0x170007CE RID: 1998
		// (get) Token: 0x06003408 RID: 13320 RVA: 0x000C9C5D File Offset: 0x000C7E5D
		// (set) Token: 0x06003409 RID: 13321 RVA: 0x000C9C65 File Offset: 0x000C7E65
		[__DynamicallyInvokable]
		public int EventId { [__DynamicallyInvokable] get; private set; }

		/// <summary>Gets or sets the level for the event.</summary>
		/// <returns>One of the enumeration values that specifies the level for the event.</returns>
		// Token: 0x170007CF RID: 1999
		// (get) Token: 0x0600340A RID: 13322 RVA: 0x000C9C6E File Offset: 0x000C7E6E
		// (set) Token: 0x0600340B RID: 13323 RVA: 0x000C9C76 File Offset: 0x000C7E76
		[__DynamicallyInvokable]
		public EventLevel Level { [__DynamicallyInvokable] get; [__DynamicallyInvokable] set; }

		/// <summary>Gets or sets the keywords for the event.</summary>
		/// <returns>A bitwise combination of the enumeration values.</returns>
		// Token: 0x170007D0 RID: 2000
		// (get) Token: 0x0600340C RID: 13324 RVA: 0x000C9C7F File Offset: 0x000C7E7F
		// (set) Token: 0x0600340D RID: 13325 RVA: 0x000C9C87 File Offset: 0x000C7E87
		[__DynamicallyInvokable]
		public EventKeywords Keywords { [__DynamicallyInvokable] get; [__DynamicallyInvokable] set; }

		/// <summary>Gets or sets the operation code for the event.</summary>
		/// <returns>One of the enumeration values that specifies the operation code.</returns>
		// Token: 0x170007D1 RID: 2001
		// (get) Token: 0x0600340E RID: 13326 RVA: 0x000C9C90 File Offset: 0x000C7E90
		// (set) Token: 0x0600340F RID: 13327 RVA: 0x000C9C98 File Offset: 0x000C7E98
		[__DynamicallyInvokable]
		public EventOpcode Opcode
		{
			[__DynamicallyInvokable]
			get
			{
				return this.m_opcode;
			}
			[__DynamicallyInvokable]
			set
			{
				this.m_opcode = value;
				this.m_opcodeSet = true;
			}
		}

		// Token: 0x170007D2 RID: 2002
		// (get) Token: 0x06003410 RID: 13328 RVA: 0x000C9CA8 File Offset: 0x000C7EA8
		internal bool IsOpcodeSet
		{
			get
			{
				return this.m_opcodeSet;
			}
		}

		/// <summary>Gets or sets the task for the event.</summary>
		/// <returns>The task for the event.</returns>
		// Token: 0x170007D3 RID: 2003
		// (get) Token: 0x06003411 RID: 13329 RVA: 0x000C9CB0 File Offset: 0x000C7EB0
		// (set) Token: 0x06003412 RID: 13330 RVA: 0x000C9CB8 File Offset: 0x000C7EB8
		[__DynamicallyInvokable]
		public EventTask Task { [__DynamicallyInvokable] get; [__DynamicallyInvokable] set; }

		/// <summary>Gets or sets an additional event log where the event should be written.</summary>
		/// <returns>An additional event log where the event should be written.</returns>
		// Token: 0x170007D4 RID: 2004
		// (get) Token: 0x06003413 RID: 13331 RVA: 0x000C9CC1 File Offset: 0x000C7EC1
		// (set) Token: 0x06003414 RID: 13332 RVA: 0x000C9CC9 File Offset: 0x000C7EC9
		[__DynamicallyInvokable]
		public EventChannel Channel { [__DynamicallyInvokable] get; [__DynamicallyInvokable] set; }

		/// <summary>Gets or sets the version of the event.</summary>
		/// <returns>The version of the event.</returns>
		// Token: 0x170007D5 RID: 2005
		// (get) Token: 0x06003415 RID: 13333 RVA: 0x000C9CD2 File Offset: 0x000C7ED2
		// (set) Token: 0x06003416 RID: 13334 RVA: 0x000C9CDA File Offset: 0x000C7EDA
		[__DynamicallyInvokable]
		public byte Version { [__DynamicallyInvokable] get; [__DynamicallyInvokable] set; }

		/// <summary>Gets or sets the message for the event.</summary>
		/// <returns>The message for the event.</returns>
		// Token: 0x170007D6 RID: 2006
		// (get) Token: 0x06003417 RID: 13335 RVA: 0x000C9CE3 File Offset: 0x000C7EE3
		// (set) Token: 0x06003418 RID: 13336 RVA: 0x000C9CEB File Offset: 0x000C7EEB
		[__DynamicallyInvokable]
		public string Message { [__DynamicallyInvokable] get; [__DynamicallyInvokable] set; }

		/// <summary>Gets or sets the <see cref="T:System.Diagnostics.Tracing.EventTags" /> value for this <see cref="T:System.Diagnostics.Tracing.EventAttribute" /> object. An event tag is a user-defined value that is passed through when the event is logged.</summary>
		/// <returns>The <see cref="T:System.Diagnostics.Tracing.EventTags" /> value for this <see cref="T:System.Diagnostics.Tracing.EventAttribute" /> object. An event tag is a user-defined value that is passed through when the event is logged.</returns>
		// Token: 0x170007D7 RID: 2007
		// (get) Token: 0x06003419 RID: 13337 RVA: 0x000C9CF4 File Offset: 0x000C7EF4
		// (set) Token: 0x0600341A RID: 13338 RVA: 0x000C9CFC File Offset: 0x000C7EFC
		[__DynamicallyInvokable]
		public EventTags Tags { [__DynamicallyInvokable] get; [__DynamicallyInvokable] set; }

		/// <summary>Specifies the behavior of the start and stop events of an activity. An activity is the region of time in an app between the start and the stop.</summary>
		/// <returns>Returns <see cref="T:System.Diagnostics.Tracing.EventActivityOptions" />.</returns>
		// Token: 0x170007D8 RID: 2008
		// (get) Token: 0x0600341B RID: 13339 RVA: 0x000C9D05 File Offset: 0x000C7F05
		// (set) Token: 0x0600341C RID: 13340 RVA: 0x000C9D0D File Offset: 0x000C7F0D
		[__DynamicallyInvokable]
		public EventActivityOptions ActivityOptions { [__DynamicallyInvokable] get; [__DynamicallyInvokable] set; }

		// Token: 0x040016E7 RID: 5863
		private EventOpcode m_opcode;

		// Token: 0x040016E8 RID: 5864
		private bool m_opcodeSet;
	}
}
