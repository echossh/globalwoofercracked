﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000426 RID: 1062
	internal sealed class BooleanTypeInfo : TraceLoggingTypeInfo<bool>
	{
		// Token: 0x0600353D RID: 13629 RVA: 0x000CE815 File Offset: 0x000CCA15
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddScalar(name, Statics.Format8(format, TraceLoggingDataType.Boolean8));
		}

		// Token: 0x0600353E RID: 13630 RVA: 0x000CE829 File Offset: 0x000CCA29
		public override void WriteData(TraceLoggingDataCollector collector, ref bool value)
		{
			collector.AddScalar(value);
		}
	}
}
