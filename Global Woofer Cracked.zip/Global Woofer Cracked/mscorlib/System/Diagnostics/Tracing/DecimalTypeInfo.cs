﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000450 RID: 1104
	internal sealed class DecimalTypeInfo : TraceLoggingTypeInfo<decimal>
	{
		// Token: 0x060035C4 RID: 13764 RVA: 0x000CEF60 File Offset: 0x000CD160
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddScalar(name, Statics.MakeDataType(TraceLoggingDataType.Double, format));
		}

		// Token: 0x060035C5 RID: 13765 RVA: 0x000CEF71 File Offset: 0x000CD171
		public override void WriteData(TraceLoggingDataCollector collector, ref decimal value)
		{
			collector.AddScalar((double)value);
		}
	}
}
