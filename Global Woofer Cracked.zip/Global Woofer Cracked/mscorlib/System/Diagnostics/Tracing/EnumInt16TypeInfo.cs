﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000444 RID: 1092
	internal sealed class EnumInt16TypeInfo<EnumType> : TraceLoggingTypeInfo<EnumType>
	{
		// Token: 0x06003599 RID: 13721 RVA: 0x000CECBA File Offset: 0x000CCEBA
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddScalar(name, Statics.Format16(format, TraceLoggingDataType.Int16));
		}

		// Token: 0x0600359A RID: 13722 RVA: 0x000CECCA File Offset: 0x000CCECA
		public override void WriteData(TraceLoggingDataCollector collector, ref EnumType value)
		{
			collector.AddScalar(EnumHelper<short>.Cast<EnumType>(value));
		}

		// Token: 0x0600359B RID: 13723 RVA: 0x000CECDD File Offset: 0x000CCEDD
		public override object GetData(object value)
		{
			return value;
		}
	}
}
