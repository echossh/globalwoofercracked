﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x0200040D RID: 1037
	internal sealed class ArrayTypeInfo<ElementType> : TraceLoggingTypeInfo<ElementType[]>
	{
		// Token: 0x060034B1 RID: 13489 RVA: 0x000CD17B File Offset: 0x000CB37B
		public ArrayTypeInfo(TraceLoggingTypeInfo<ElementType> elementInfo)
		{
			this.elementInfo = elementInfo;
		}

		// Token: 0x060034B2 RID: 13490 RVA: 0x000CD18A File Offset: 0x000CB38A
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.BeginBufferedArray();
			this.elementInfo.WriteMetadata(collector, name, format);
			collector.EndBufferedArray();
		}

		// Token: 0x060034B3 RID: 13491 RVA: 0x000CD1A8 File Offset: 0x000CB3A8
		public override void WriteData(TraceLoggingDataCollector collector, ref ElementType[] value)
		{
			int bookmark = collector.BeginBufferedArray();
			int count = 0;
			if (value != null)
			{
				count = value.Length;
				for (int i = 0; i < value.Length; i++)
				{
					this.elementInfo.WriteData(collector, ref value[i]);
				}
			}
			collector.EndBufferedArray(bookmark, count);
		}

		// Token: 0x060034B4 RID: 13492 RVA: 0x000CD1F4 File Offset: 0x000CB3F4
		public override object GetData(object value)
		{
			ElementType[] array = (ElementType[])value;
			object[] array2 = new object[array.Length];
			for (int i = 0; i < array.Length; i++)
			{
				array2[i] = this.elementInfo.GetData(array[i]);
			}
			return array2;
		}

		// Token: 0x04001752 RID: 5970
		private readonly TraceLoggingTypeInfo<ElementType> elementInfo;
	}
}
