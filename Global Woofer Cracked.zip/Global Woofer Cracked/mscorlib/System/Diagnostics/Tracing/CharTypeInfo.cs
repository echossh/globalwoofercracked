﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000433 RID: 1075
	internal sealed class CharTypeInfo : TraceLoggingTypeInfo<char>
	{
		// Token: 0x06003564 RID: 13668 RVA: 0x000CE9DF File Offset: 0x000CCBDF
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddScalar(name, Statics.Format16(format, TraceLoggingDataType.Char16));
		}

		// Token: 0x06003565 RID: 13669 RVA: 0x000CE9F3 File Offset: 0x000CCBF3
		public override void WriteData(TraceLoggingDataCollector collector, ref char value)
		{
			collector.AddScalar(value);
		}
	}
}
