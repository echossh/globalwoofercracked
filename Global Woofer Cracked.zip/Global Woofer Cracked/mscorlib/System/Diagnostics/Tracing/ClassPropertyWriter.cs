﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000422 RID: 1058
	internal class ClassPropertyWriter<ContainerType, ValueType> : PropertyAccessor<ContainerType>
	{
		// Token: 0x06003532 RID: 13618 RVA: 0x000CE6C6 File Offset: 0x000CC8C6
		public ClassPropertyWriter(PropertyAnalysis property)
		{
			this.valueTypeInfo = (TraceLoggingTypeInfo<ValueType>)property.typeInfo;
			this.getter = (ClassPropertyWriter<ContainerType, ValueType>.Getter)Statics.CreateDelegate(typeof(ClassPropertyWriter<ContainerType, ValueType>.Getter), property.getterInfo);
		}

		// Token: 0x06003533 RID: 13619 RVA: 0x000CE700 File Offset: 0x000CC900
		public override void Write(TraceLoggingDataCollector collector, ref ContainerType container)
		{
			ValueType valueType = (container == null) ? default(ValueType) : this.getter(container);
			this.valueTypeInfo.WriteData(collector, ref valueType);
		}

		// Token: 0x06003534 RID: 13620 RVA: 0x000CE748 File Offset: 0x000CC948
		public override object GetData(ContainerType container)
		{
			return (container == null) ? default(ValueType) : this.getter(container);
		}

		// Token: 0x04001799 RID: 6041
		private readonly TraceLoggingTypeInfo<ValueType> valueTypeInfo;

		// Token: 0x0400179A RID: 6042
		private readonly ClassPropertyWriter<ContainerType, ValueType>.Getter getter;

		// Token: 0x02000B67 RID: 2919
		// (Invoke) Token: 0x06006B69 RID: 27497
		private delegate ValueType Getter(ContainerType container);
	}
}
