﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000446 RID: 1094
	internal sealed class EnumInt32TypeInfo<EnumType> : TraceLoggingTypeInfo<EnumType>
	{
		// Token: 0x060035A1 RID: 13729 RVA: 0x000CED16 File Offset: 0x000CCF16
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddScalar(name, Statics.Format32(format, TraceLoggingDataType.Int32));
		}

		// Token: 0x060035A2 RID: 13730 RVA: 0x000CED26 File Offset: 0x000CCF26
		public override void WriteData(TraceLoggingDataCollector collector, ref EnumType value)
		{
			collector.AddScalar(EnumHelper<int>.Cast<EnumType>(value));
		}

		// Token: 0x060035A3 RID: 13731 RVA: 0x000CED39 File Offset: 0x000CCF39
		public override object GetData(object value)
		{
			return value;
		}
	}
}
