﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000448 RID: 1096
	internal sealed class EnumInt64TypeInfo<EnumType> : TraceLoggingTypeInfo<EnumType>
	{
		// Token: 0x060035A9 RID: 13737 RVA: 0x000CED72 File Offset: 0x000CCF72
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddScalar(name, Statics.Format64(format, TraceLoggingDataType.Int64));
		}

		// Token: 0x060035AA RID: 13738 RVA: 0x000CED83 File Offset: 0x000CCF83
		public override void WriteData(TraceLoggingDataCollector collector, ref EnumType value)
		{
			collector.AddScalar(EnumHelper<long>.Cast<EnumType>(value));
		}

		// Token: 0x060035AB RID: 13739 RVA: 0x000CED96 File Offset: 0x000CCF96
		public override object GetData(object value)
		{
			return value;
		}
	}
}
