﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000411 RID: 1041
	internal struct EmptyStruct
	{
	}
}
