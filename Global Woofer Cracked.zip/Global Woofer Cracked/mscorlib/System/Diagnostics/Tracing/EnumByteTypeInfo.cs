﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000442 RID: 1090
	internal sealed class EnumByteTypeInfo<EnumType> : TraceLoggingTypeInfo<EnumType>
	{
		// Token: 0x06003591 RID: 13713 RVA: 0x000CEC5E File Offset: 0x000CCE5E
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddScalar(name, Statics.Format8(format, TraceLoggingDataType.UInt8));
		}

		// Token: 0x06003592 RID: 13714 RVA: 0x000CEC6E File Offset: 0x000CCE6E
		public override void WriteData(TraceLoggingDataCollector collector, ref EnumType value)
		{
			collector.AddScalar(EnumHelper<byte>.Cast<EnumType>(value));
		}

		// Token: 0x06003593 RID: 13715 RVA: 0x000CEC81 File Offset: 0x000CCE81
		public override object GetData(object value)
		{
			return value;
		}
	}
}
