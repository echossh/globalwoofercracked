﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000447 RID: 1095
	internal sealed class EnumUInt32TypeInfo<EnumType> : TraceLoggingTypeInfo<EnumType>
	{
		// Token: 0x060035A5 RID: 13733 RVA: 0x000CED44 File Offset: 0x000CCF44
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddScalar(name, Statics.Format32(format, TraceLoggingDataType.UInt32));
		}

		// Token: 0x060035A6 RID: 13734 RVA: 0x000CED54 File Offset: 0x000CCF54
		public override void WriteData(TraceLoggingDataCollector collector, ref EnumType value)
		{
			collector.AddScalar(EnumHelper<uint>.Cast<EnumType>(value));
		}

		// Token: 0x060035A7 RID: 13735 RVA: 0x000CED67 File Offset: 0x000CCF67
		public override object GetData(object value)
		{
			return value;
		}
	}
}
