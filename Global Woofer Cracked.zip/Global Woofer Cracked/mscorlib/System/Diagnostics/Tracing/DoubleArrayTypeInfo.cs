﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000440 RID: 1088
	internal sealed class DoubleArrayTypeInfo : TraceLoggingTypeInfo<double[]>
	{
		// Token: 0x0600358B RID: 13707 RVA: 0x000CEC18 File Offset: 0x000CCE18
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddArray(name, Statics.Format64(format, TraceLoggingDataType.Double));
		}

		// Token: 0x0600358C RID: 13708 RVA: 0x000CEC29 File Offset: 0x000CCE29
		public override void WriteData(TraceLoggingDataCollector collector, ref double[] value)
		{
			collector.AddArray(value);
		}
	}
}
