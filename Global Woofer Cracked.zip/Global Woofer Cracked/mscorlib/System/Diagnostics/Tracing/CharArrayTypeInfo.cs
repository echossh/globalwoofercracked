﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x0200043F RID: 1087
	internal sealed class CharArrayTypeInfo : TraceLoggingTypeInfo<char[]>
	{
		// Token: 0x06003588 RID: 13704 RVA: 0x000CEBF2 File Offset: 0x000CCDF2
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddArray(name, Statics.Format16(format, TraceLoggingDataType.Char16));
		}

		// Token: 0x06003589 RID: 13705 RVA: 0x000CEC06 File Offset: 0x000CCE06
		public override void WriteData(TraceLoggingDataCollector collector, ref char[] value)
		{
			collector.AddArray(value);
		}
	}
}
