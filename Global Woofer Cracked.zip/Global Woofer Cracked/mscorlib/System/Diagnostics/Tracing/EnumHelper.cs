﻿using System;
using System.Reflection;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000413 RID: 1043
	internal static class EnumHelper<UnderlyingType>
	{
		// Token: 0x060034CF RID: 13519 RVA: 0x000CD8F8 File Offset: 0x000CBAF8
		public static UnderlyingType Cast<ValueType>(ValueType value)
		{
			return EnumHelper<UnderlyingType>.Caster<ValueType>.Instance(value);
		}

		// Token: 0x060034D0 RID: 13520 RVA: 0x000CD905 File Offset: 0x000CBB05
		internal static UnderlyingType Identity(UnderlyingType value)
		{
			return value;
		}

		// Token: 0x04001761 RID: 5985
		private static readonly MethodInfo IdentityInfo = Statics.GetDeclaredStaticMethod(typeof(EnumHelper<UnderlyingType>), "Identity");

		// Token: 0x02000B62 RID: 2914
		// (Invoke) Token: 0x06006B5A RID: 27482
		private delegate UnderlyingType Transformer<ValueType>(ValueType value);

		// Token: 0x02000B63 RID: 2915
		private static class Caster<ValueType>
		{
			// Token: 0x04003437 RID: 13367
			public static readonly EnumHelper<UnderlyingType>.Transformer<ValueType> Instance = (EnumHelper<UnderlyingType>.Transformer<ValueType>)Statics.CreateDelegate(typeof(EnumHelper<UnderlyingType>.Transformer<ValueType>), EnumHelper<UnderlyingType>.IdentityInfo);
		}
	}
}
