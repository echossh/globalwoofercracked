﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x0200040F RID: 1039
	internal abstract class ConcurrentSetItem<KeyType, ItemType> where ItemType : ConcurrentSetItem<KeyType, ItemType>
	{
		// Token: 0x060034B7 RID: 13495
		public abstract int Compare(ItemType other);

		// Token: 0x060034B8 RID: 13496
		public abstract int Compare(KeyType key);
	}
}
