﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000443 RID: 1091
	internal sealed class EnumSByteTypeInfo<EnumType> : TraceLoggingTypeInfo<EnumType>
	{
		// Token: 0x06003595 RID: 13717 RVA: 0x000CEC8C File Offset: 0x000CCE8C
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddScalar(name, Statics.Format8(format, TraceLoggingDataType.Int8));
		}

		// Token: 0x06003596 RID: 13718 RVA: 0x000CEC9C File Offset: 0x000CCE9C
		public override void WriteData(TraceLoggingDataCollector collector, ref EnumType value)
		{
			collector.AddScalar(EnumHelper<sbyte>.Cast<EnumType>(value));
		}

		// Token: 0x06003597 RID: 13719 RVA: 0x000CECAF File Offset: 0x000CCEAF
		public override object GetData(object value)
		{
			return value;
		}
	}
}
