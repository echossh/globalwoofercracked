﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x0200044D RID: 1101
	internal sealed class DateTimeTypeInfo : TraceLoggingTypeInfo<DateTime>
	{
		// Token: 0x060035BB RID: 13755 RVA: 0x000CEE5D File Offset: 0x000CD05D
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddScalar(name, Statics.MakeDataType(TraceLoggingDataType.FileTime, format));
		}

		// Token: 0x060035BC RID: 13756 RVA: 0x000CEE70 File Offset: 0x000CD070
		public override void WriteData(TraceLoggingDataCollector collector, ref DateTime value)
		{
			long ticks = value.Ticks;
			collector.AddScalar((ticks < 504911232000000000L) ? 0L : (ticks - 504911232000000000L));
		}
	}
}
