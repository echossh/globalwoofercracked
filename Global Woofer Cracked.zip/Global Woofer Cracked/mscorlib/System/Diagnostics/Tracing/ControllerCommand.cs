﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x020003F1 RID: 1009
	internal enum ControllerCommand
	{
		// Token: 0x0400167F RID: 5759
		Update,
		// Token: 0x04001680 RID: 5760
		SendManifest = -1,
		// Token: 0x04001681 RID: 5761
		Enable = -2,
		// Token: 0x04001682 RID: 5762
		Disable = -3
	}
}
