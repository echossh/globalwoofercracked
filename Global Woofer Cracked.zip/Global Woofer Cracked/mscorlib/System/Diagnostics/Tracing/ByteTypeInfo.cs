﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000427 RID: 1063
	internal sealed class ByteTypeInfo : TraceLoggingTypeInfo<byte>
	{
		// Token: 0x06003540 RID: 13632 RVA: 0x000CE83B File Offset: 0x000CCA3B
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddScalar(name, Statics.Format8(format, TraceLoggingDataType.UInt8));
		}

		// Token: 0x06003541 RID: 13633 RVA: 0x000CE84B File Offset: 0x000CCA4B
		public override void WriteData(TraceLoggingDataCollector collector, ref byte value)
		{
			collector.AddScalar(value);
		}
	}
}
