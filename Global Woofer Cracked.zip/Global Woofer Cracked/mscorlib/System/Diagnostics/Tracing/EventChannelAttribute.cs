﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x020003FC RID: 1020
	[AttributeUsage(AttributeTargets.Field)]
	internal class EventChannelAttribute : Attribute
	{
		// Token: 0x170007D9 RID: 2009
		// (get) Token: 0x0600341E RID: 13342 RVA: 0x000C9D1E File Offset: 0x000C7F1E
		// (set) Token: 0x0600341F RID: 13343 RVA: 0x000C9D26 File Offset: 0x000C7F26
		public bool Enabled { get; set; }

		// Token: 0x170007DA RID: 2010
		// (get) Token: 0x06003420 RID: 13344 RVA: 0x000C9D2F File Offset: 0x000C7F2F
		// (set) Token: 0x06003421 RID: 13345 RVA: 0x000C9D37 File Offset: 0x000C7F37
		public EventChannelType EventChannelType { get; set; }
	}
}
