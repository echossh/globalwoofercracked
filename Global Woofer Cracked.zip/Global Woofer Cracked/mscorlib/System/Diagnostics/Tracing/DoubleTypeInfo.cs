﻿using System;

namespace System.Diagnostics.Tracing
{
	// Token: 0x02000431 RID: 1073
	internal sealed class DoubleTypeInfo : TraceLoggingTypeInfo<double>
	{
		// Token: 0x0600355E RID: 13662 RVA: 0x000CE999 File Offset: 0x000CCB99
		public override void WriteMetadata(TraceLoggingMetadataCollector collector, string name, EventFieldFormat format)
		{
			collector.AddScalar(name, Statics.Format64(format, TraceLoggingDataType.Double));
		}

		// Token: 0x0600355F RID: 13663 RVA: 0x000CE9AA File Offset: 0x000CCBAA
		public override void WriteData(TraceLoggingDataCollector collector, ref double value)
		{
			collector.AddScalar(value);
		}
	}
}
