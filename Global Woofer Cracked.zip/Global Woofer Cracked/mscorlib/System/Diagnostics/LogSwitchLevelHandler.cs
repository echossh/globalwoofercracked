﻿using System;

namespace System.Diagnostics
{
	// Token: 0x020003C6 RID: 966
	// (Invoke) Token: 0x0600320E RID: 12814
	[Serializable]
	internal delegate void LogSwitchLevelHandler(LogSwitch ls, LoggingLevels newLevel);
}
