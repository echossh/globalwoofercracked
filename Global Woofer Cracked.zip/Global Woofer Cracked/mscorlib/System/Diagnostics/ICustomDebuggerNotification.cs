﻿using System;

namespace System.Diagnostics
{
	// Token: 0x020003C4 RID: 964
	internal interface ICustomDebuggerNotification
	{
	}
}
