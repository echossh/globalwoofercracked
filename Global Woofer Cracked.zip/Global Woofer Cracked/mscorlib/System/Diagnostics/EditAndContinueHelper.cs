﻿using System;

namespace System.Diagnostics
{
	// Token: 0x020003CD RID: 973
	[Serializable]
	internal sealed class EditAndContinueHelper
	{
		// Token: 0x04001632 RID: 5682
		private object _objectReference;
	}
}
