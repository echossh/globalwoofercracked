﻿using System;

namespace System.Diagnostics
{
	// Token: 0x020003B7 RID: 951
	[Serializable]
	internal enum AssertFilters
	{
		// Token: 0x040015E0 RID: 5600
		FailDebug,
		// Token: 0x040015E1 RID: 5601
		FailIgnore,
		// Token: 0x040015E2 RID: 5602
		FailTerminate,
		// Token: 0x040015E3 RID: 5603
		FailContinueFilter
	}
}
