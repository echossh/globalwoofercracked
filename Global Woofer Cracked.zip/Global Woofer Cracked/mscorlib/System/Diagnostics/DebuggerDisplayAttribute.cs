﻿using System;
using System.Runtime.InteropServices;

namespace System.Diagnostics
{
	/// <summary>Determines how a class or field is displayed in the debugger variable windows.</summary>
	// Token: 0x020003C2 RID: 962
	[AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Enum | AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Delegate, AllowMultiple = true)]
	[ComVisible(true)]
	[__DynamicallyInvokable]
	public sealed class DebuggerDisplayAttribute : Attribute
	{
		/// <summary>Initializes a new instance of the <see cref="T:System.Diagnostics.DebuggerDisplayAttribute" /> class.</summary>
		/// <param name="value">The string to be displayed in the value column for instances of the type; an empty string ("") causes the value column to be hidden.</param>
		// Token: 0x060031F1 RID: 12785 RVA: 0x000C02A1 File Offset: 0x000BE4A1
		[__DynamicallyInvokable]
		public DebuggerDisplayAttribute(string value)
		{
			if (value == null)
			{
				this.value = "";
			}
			else
			{
				this.value = value;
			}
			this.name = "";
			this.type = "";
		}

		/// <summary>Gets the string to display in the value column of the debugger variable windows.</summary>
		/// <returns>The string to display in the value column of the debugger variable.</returns>
		// Token: 0x17000762 RID: 1890
		// (get) Token: 0x060031F2 RID: 12786 RVA: 0x000C02D6 File Offset: 0x000BE4D6
		[__DynamicallyInvokable]
		public string Value
		{
			[__DynamicallyInvokable]
			get
			{
				return this.value;
			}
		}

		/// <summary>Gets or sets the name to display in the debugger variable windows.</summary>
		/// <returns>The name to display in the debugger variable windows.</returns>
		// Token: 0x17000763 RID: 1891
		// (get) Token: 0x060031F3 RID: 12787 RVA: 0x000C02DE File Offset: 0x000BE4DE
		// (set) Token: 0x060031F4 RID: 12788 RVA: 0x000C02E6 File Offset: 0x000BE4E6
		[__DynamicallyInvokable]
		public string Name
		{
			[__DynamicallyInvokable]
			get
			{
				return this.name;
			}
			[__DynamicallyInvokable]
			set
			{
				this.name = value;
			}
		}

		/// <summary>Gets or sets the string to display in the type column of the debugger variable windows.</summary>
		/// <returns>The string to display in the type column of the debugger variable windows.</returns>
		// Token: 0x17000764 RID: 1892
		// (get) Token: 0x060031F5 RID: 12789 RVA: 0x000C02EF File Offset: 0x000BE4EF
		// (set) Token: 0x060031F6 RID: 12790 RVA: 0x000C02F7 File Offset: 0x000BE4F7
		[__DynamicallyInvokable]
		public string Type
		{
			[__DynamicallyInvokable]
			get
			{
				return this.type;
			}
			[__DynamicallyInvokable]
			set
			{
				this.type = value;
			}
		}

		/// <summary>Gets or sets the type of the attribute's target.</summary>
		/// <returns>The attribute's target type.</returns>
		/// <exception cref="T:System.ArgumentNullException">
		///   <see cref="P:System.Diagnostics.DebuggerDisplayAttribute.Target" /> is set to <see langword="null" />.</exception>
		// Token: 0x17000765 RID: 1893
		// (get) Token: 0x060031F8 RID: 12792 RVA: 0x000C0329 File Offset: 0x000BE529
		// (set) Token: 0x060031F7 RID: 12791 RVA: 0x000C0300 File Offset: 0x000BE500
		[__DynamicallyInvokable]
		public Type Target
		{
			[__DynamicallyInvokable]
			get
			{
				return this.target;
			}
			[__DynamicallyInvokable]
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException("value");
				}
				this.targetName = value.AssemblyQualifiedName;
				this.target = value;
			}
		}

		/// <summary>Gets or sets the type name of the attribute's target.</summary>
		/// <returns>The name of the attribute's target type.</returns>
		// Token: 0x17000766 RID: 1894
		// (get) Token: 0x060031F9 RID: 12793 RVA: 0x000C0331 File Offset: 0x000BE531
		// (set) Token: 0x060031FA RID: 12794 RVA: 0x000C0339 File Offset: 0x000BE539
		[__DynamicallyInvokable]
		public string TargetTypeName
		{
			[__DynamicallyInvokable]
			get
			{
				return this.targetName;
			}
			[__DynamicallyInvokable]
			set
			{
				this.targetName = value;
			}
		}

		// Token: 0x040015F0 RID: 5616
		private string name;

		// Token: 0x040015F1 RID: 5617
		private string value;

		// Token: 0x040015F2 RID: 5618
		private string type;

		// Token: 0x040015F3 RID: 5619
		private string targetName;

		// Token: 0x040015F4 RID: 5620
		private Type target;
	}
}
