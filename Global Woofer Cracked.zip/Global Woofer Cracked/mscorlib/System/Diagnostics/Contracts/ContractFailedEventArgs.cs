﻿using System;
using System.Runtime.ConstrainedExecution;
using System.Security;

namespace System.Diagnostics.Contracts
{
	/// <summary>Provides methods and data for the <see cref="E:System.Diagnostics.Contracts.Contract.ContractFailed" /> event.</summary>
	// Token: 0x020003EA RID: 1002
	[__DynamicallyInvokable]
	public sealed class ContractFailedEventArgs : EventArgs
	{
		/// <summary>Provides data for the <see cref="E:System.Diagnostics.Contracts.Contract.ContractFailed" /> event.</summary>
		/// <param name="failureKind">One of the enumeration values that specifies the contract that failed.</param>
		/// <param name="message">The message for the event.</param>
		/// <param name="condition">The condition for the event.</param>
		/// <param name="originalException">The exception that caused the event.</param>
		// Token: 0x060032F3 RID: 13043 RVA: 0x000C2128 File Offset: 0x000C0328
		[ReliabilityContract(Consistency.WillNotCorruptState, Cer.MayFail)]
		[__DynamicallyInvokable]
		public ContractFailedEventArgs(ContractFailureKind failureKind, string message, string condition, Exception originalException)
		{
			this._failureKind = failureKind;
			this._message = message;
			this._condition = condition;
			this._originalException = originalException;
		}

		/// <summary>Gets the message that describes the <see cref="E:System.Diagnostics.Contracts.Contract.ContractFailed" /> event.</summary>
		/// <returns>The message that describes the event.</returns>
		// Token: 0x17000792 RID: 1938
		// (get) Token: 0x060032F4 RID: 13044 RVA: 0x000C214D File Offset: 0x000C034D
		[__DynamicallyInvokable]
		public string Message
		{
			[__DynamicallyInvokable]
			get
			{
				return this._message;
			}
		}

		/// <summary>Gets the condition for the failure of the contract.</summary>
		/// <returns>The condition for the failure.</returns>
		// Token: 0x17000793 RID: 1939
		// (get) Token: 0x060032F5 RID: 13045 RVA: 0x000C2155 File Offset: 0x000C0355
		[__DynamicallyInvokable]
		public string Condition
		{
			[__DynamicallyInvokable]
			get
			{
				return this._condition;
			}
		}

		/// <summary>Gets the type of contract that failed.</summary>
		/// <returns>One of the enumeration values that specifies the type of contract that failed.</returns>
		// Token: 0x17000794 RID: 1940
		// (get) Token: 0x060032F6 RID: 13046 RVA: 0x000C215D File Offset: 0x000C035D
		[__DynamicallyInvokable]
		public ContractFailureKind FailureKind
		{
			[__DynamicallyInvokable]
			get
			{
				return this._failureKind;
			}
		}

		/// <summary>Gets the original exception that caused the <see cref="E:System.Diagnostics.Contracts.Contract.ContractFailed" /> event.</summary>
		/// <returns>The exception that caused the event.</returns>
		// Token: 0x17000795 RID: 1941
		// (get) Token: 0x060032F7 RID: 13047 RVA: 0x000C2165 File Offset: 0x000C0365
		[__DynamicallyInvokable]
		public Exception OriginalException
		{
			[__DynamicallyInvokable]
			get
			{
				return this._originalException;
			}
		}

		/// <summary>Indicates whether the <see cref="E:System.Diagnostics.Contracts.Contract.ContractFailed" /> event has been handled.</summary>
		/// <returns>
		///   <see langword="true" /> if the event has been handled; otherwise, <see langword="false" />.</returns>
		// Token: 0x17000796 RID: 1942
		// (get) Token: 0x060032F8 RID: 13048 RVA: 0x000C216D File Offset: 0x000C036D
		[__DynamicallyInvokable]
		public bool Handled
		{
			[__DynamicallyInvokable]
			get
			{
				return this._handled;
			}
		}

		/// <summary>Sets the <see cref="P:System.Diagnostics.Contracts.ContractFailedEventArgs.Handled" /> property to <see langword="true" />.</summary>
		// Token: 0x060032F9 RID: 13049 RVA: 0x000C2175 File Offset: 0x000C0375
		[SecurityCritical]
		[__DynamicallyInvokable]
		public void SetHandled()
		{
			this._handled = true;
		}

		/// <summary>Indicates whether the code contract escalation policy should be applied.</summary>
		/// <returns>
		///   <see langword="true" /> to apply the escalation policy; otherwise, <see langword="false" />. The default is <see langword="false" />.</returns>
		// Token: 0x17000797 RID: 1943
		// (get) Token: 0x060032FA RID: 13050 RVA: 0x000C217E File Offset: 0x000C037E
		[__DynamicallyInvokable]
		public bool Unwind
		{
			[__DynamicallyInvokable]
			get
			{
				return this._unwind;
			}
		}

		/// <summary>Sets the <see cref="P:System.Diagnostics.Contracts.ContractFailedEventArgs.Unwind" /> property to <see langword="true" />.</summary>
		// Token: 0x060032FB RID: 13051 RVA: 0x000C2186 File Offset: 0x000C0386
		[SecurityCritical]
		[__DynamicallyInvokable]
		public void SetUnwind()
		{
			this._unwind = true;
		}

		// Token: 0x0400165C RID: 5724
		private ContractFailureKind _failureKind;

		// Token: 0x0400165D RID: 5725
		private string _message;

		// Token: 0x0400165E RID: 5726
		private string _condition;

		// Token: 0x0400165F RID: 5727
		private Exception _originalException;

		// Token: 0x04001660 RID: 5728
		private bool _handled;

		// Token: 0x04001661 RID: 5729
		private bool _unwind;

		// Token: 0x04001662 RID: 5730
		internal Exception thrownDuringHandler;
	}
}
