﻿using System;
using System.Runtime.Serialization;
using System.Security;

namespace System.Diagnostics.Contracts
{
	// Token: 0x020003EB RID: 1003
	[Serializable]
	internal sealed class ContractException : Exception
	{
		// Token: 0x17000798 RID: 1944
		// (get) Token: 0x060032FC RID: 13052 RVA: 0x000C218F File Offset: 0x000C038F
		public ContractFailureKind Kind
		{
			get
			{
				return this._Kind;
			}
		}

		// Token: 0x17000799 RID: 1945
		// (get) Token: 0x060032FD RID: 13053 RVA: 0x000C2197 File Offset: 0x000C0397
		public string Failure
		{
			get
			{
				return this.Message;
			}
		}

		// Token: 0x1700079A RID: 1946
		// (get) Token: 0x060032FE RID: 13054 RVA: 0x000C219F File Offset: 0x000C039F
		public string UserMessage
		{
			get
			{
				return this._UserMessage;
			}
		}

		// Token: 0x1700079B RID: 1947
		// (get) Token: 0x060032FF RID: 13055 RVA: 0x000C21A7 File Offset: 0x000C03A7
		public string Condition
		{
			get
			{
				return this._Condition;
			}
		}

		// Token: 0x06003300 RID: 13056 RVA: 0x000C21AF File Offset: 0x000C03AF
		private ContractException()
		{
			base.HResult = -2146233022;
		}

		// Token: 0x06003301 RID: 13057 RVA: 0x000C21C2 File Offset: 0x000C03C2
		public ContractException(ContractFailureKind kind, string failure, string userMessage, string condition, Exception innerException) : base(failure, innerException)
		{
			base.HResult = -2146233022;
			this._Kind = kind;
			this._UserMessage = userMessage;
			this._Condition = condition;
		}

		// Token: 0x06003302 RID: 13058 RVA: 0x000C21EE File Offset: 0x000C03EE
		private ContractException(SerializationInfo info, StreamingContext context) : base(info, context)
		{
			this._Kind = (ContractFailureKind)info.GetInt32("Kind");
			this._UserMessage = info.GetString("UserMessage");
			this._Condition = info.GetString("Condition");
		}

		// Token: 0x06003303 RID: 13059 RVA: 0x000C222C File Offset: 0x000C042C
		[SecurityCritical]
		public override void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			base.GetObjectData(info, context);
			info.AddValue("Kind", this._Kind);
			info.AddValue("UserMessage", this._UserMessage);
			info.AddValue("Condition", this._Condition);
		}

		// Token: 0x04001663 RID: 5731
		private readonly ContractFailureKind _Kind;

		// Token: 0x04001664 RID: 5732
		private readonly string _UserMessage;

		// Token: 0x04001665 RID: 5733
		private readonly string _Condition;
	}
}
