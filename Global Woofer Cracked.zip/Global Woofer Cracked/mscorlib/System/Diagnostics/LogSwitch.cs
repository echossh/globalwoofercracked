﻿using System;
using System.Security;

namespace System.Diagnostics
{
	// Token: 0x020003C9 RID: 969
	[Serializable]
	internal class LogSwitch
	{
		// Token: 0x0600322A RID: 12842 RVA: 0x000C07B7 File Offset: 0x000BE9B7
		private LogSwitch()
		{
		}

		// Token: 0x0600322B RID: 12843 RVA: 0x000C07C0 File Offset: 0x000BE9C0
		[SecuritySafeCritical]
		public LogSwitch(string name, string description, LogSwitch parent)
		{
			if (name != null && name.Length == 0)
			{
				throw new ArgumentOutOfRangeException("Name", Environment.GetResourceString("Argument_StringZeroLength"));
			}
			if (name != null && parent != null)
			{
				this.strName = name;
				this.strDescription = description;
				this.iLevel = LoggingLevels.ErrorLevel;
				this.iOldLevel = this.iLevel;
				this.ParentSwitch = parent;
				Log.m_Hashtable.Add(this.strName, this);
				Log.AddLogSwitch(this);
				return;
			}
			throw new ArgumentNullException((name == null) ? "name" : "parent");
		}

		// Token: 0x0600322C RID: 12844 RVA: 0x000C0854 File Offset: 0x000BEA54
		[SecuritySafeCritical]
		internal LogSwitch(string name, string description)
		{
			this.strName = name;
			this.strDescription = description;
			this.iLevel = LoggingLevels.ErrorLevel;
			this.iOldLevel = this.iLevel;
			this.ParentSwitch = null;
			Log.m_Hashtable.Add(this.strName, this);
			Log.AddLogSwitch(this);
		}

		// Token: 0x1700076D RID: 1901
		// (get) Token: 0x0600322D RID: 12845 RVA: 0x000C08AD File Offset: 0x000BEAAD
		public virtual string Name
		{
			get
			{
				return this.strName;
			}
		}

		// Token: 0x1700076E RID: 1902
		// (get) Token: 0x0600322E RID: 12846 RVA: 0x000C08B5 File Offset: 0x000BEAB5
		public virtual string Description
		{
			get
			{
				return this.strDescription;
			}
		}

		// Token: 0x1700076F RID: 1903
		// (get) Token: 0x0600322F RID: 12847 RVA: 0x000C08BD File Offset: 0x000BEABD
		public virtual LogSwitch Parent
		{
			get
			{
				return this.ParentSwitch;
			}
		}

		// Token: 0x17000770 RID: 1904
		// (get) Token: 0x06003230 RID: 12848 RVA: 0x000C08C5 File Offset: 0x000BEAC5
		// (set) Token: 0x06003231 RID: 12849 RVA: 0x000C08D0 File Offset: 0x000BEAD0
		public virtual LoggingLevels MinimumLevel
		{
			get
			{
				return this.iLevel;
			}
			[SecuritySafeCritical]
			set
			{
				this.iLevel = value;
				this.iOldLevel = value;
				string strParentName = (this.ParentSwitch != null) ? this.ParentSwitch.Name : "";
				if (Debugger.IsAttached)
				{
					Log.ModifyLogSwitch((int)this.iLevel, this.strName, strParentName);
				}
				Log.InvokeLogSwitchLevelHandlers(this, this.iLevel);
			}
		}

		// Token: 0x06003232 RID: 12850 RVA: 0x000C0933 File Offset: 0x000BEB33
		public virtual bool CheckLevel(LoggingLevels level)
		{
			return this.iLevel <= level || (this.ParentSwitch != null && this.ParentSwitch.CheckLevel(level));
		}

		// Token: 0x06003233 RID: 12851 RVA: 0x000C0958 File Offset: 0x000BEB58
		public static LogSwitch GetSwitch(string name)
		{
			return (LogSwitch)Log.m_Hashtable[name];
		}

		// Token: 0x0400160E RID: 5646
		internal string strName;

		// Token: 0x0400160F RID: 5647
		internal string strDescription;

		// Token: 0x04001610 RID: 5648
		private LogSwitch ParentSwitch;

		// Token: 0x04001611 RID: 5649
		internal volatile LoggingLevels iLevel;

		// Token: 0x04001612 RID: 5650
		internal volatile LoggingLevels iOldLevel;
	}
}
