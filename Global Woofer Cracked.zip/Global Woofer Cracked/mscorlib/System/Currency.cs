﻿using System;
using System.Runtime.CompilerServices;
using System.Security;

namespace System
{
	// Token: 0x020000CF RID: 207
	[Serializable]
	internal struct Currency
	{
		// Token: 0x06000CE6 RID: 3302 RVA: 0x000275C6 File Offset: 0x000257C6
		public Currency(decimal value)
		{
			this.m_value = decimal.ToCurrency(value).m_value;
		}

		// Token: 0x06000CE7 RID: 3303 RVA: 0x000275D9 File Offset: 0x000257D9
		internal Currency(long value, int ignored)
		{
			this.m_value = value;
		}

		// Token: 0x06000CE8 RID: 3304 RVA: 0x000275E2 File Offset: 0x000257E2
		public static Currency FromOACurrency(long cy)
		{
			return new Currency(cy, 0);
		}

		// Token: 0x06000CE9 RID: 3305 RVA: 0x000275EB File Offset: 0x000257EB
		public long ToOACurrency()
		{
			return this.m_value;
		}

		// Token: 0x06000CEA RID: 3306 RVA: 0x000275F4 File Offset: 0x000257F4
		[SecuritySafeCritical]
		public static decimal ToDecimal(Currency c)
		{
			decimal result = 0m;
			Currency.FCallToDecimal(ref result, c);
			return result;
		}

		// Token: 0x06000CEB RID: 3307
		[SecurityCritical]
		[MethodImpl(MethodImplOptions.InternalCall)]
		private static extern void FCallToDecimal(ref decimal result, Currency c);

		// Token: 0x04000539 RID: 1337
		internal long m_value;
	}
}
