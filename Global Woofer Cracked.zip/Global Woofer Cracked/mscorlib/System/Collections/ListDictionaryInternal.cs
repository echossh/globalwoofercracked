﻿using System;
using System.Threading;

namespace System.Collections
{
	// Token: 0x02000468 RID: 1128
	[Serializable]
	internal class ListDictionaryInternal : IDictionary, ICollection, IEnumerable
	{
		// Token: 0x17000838 RID: 2104
		public object this[object key]
		{
			get
			{
				if (key == null)
				{
					throw new ArgumentNullException("key", Environment.GetResourceString("ArgumentNull_Key"));
				}
				for (ListDictionaryInternal.DictionaryNode next = this.head; next != null; next = next.next)
				{
					if (next.key.Equals(key))
					{
						return next.value;
					}
				}
				return null;
			}
			set
			{
				if (key == null)
				{
					throw new ArgumentNullException("key", Environment.GetResourceString("ArgumentNull_Key"));
				}
				if (!key.GetType().IsSerializable)
				{
					throw new ArgumentException(Environment.GetResourceString("Argument_NotSerializable"), "key");
				}
				if (value != null && !value.GetType().IsSerializable)
				{
					throw new ArgumentException(Environment.GetResourceString("Argument_NotSerializable"), "value");
				}
				this.version++;
				ListDictionaryInternal.DictionaryNode dictionaryNode = null;
				ListDictionaryInternal.DictionaryNode next = this.head;
				while (next != null && !next.key.Equals(key))
				{
					dictionaryNode = next;
					next = next.next;
				}
				if (next != null)
				{
					next.value = value;
					return;
				}
				ListDictionaryInternal.DictionaryNode dictionaryNode2 = new ListDictionaryInternal.DictionaryNode();
				dictionaryNode2.key = key;
				dictionaryNode2.value = value;
				if (dictionaryNode != null)
				{
					dictionaryNode.next = dictionaryNode2;
				}
				else
				{
					this.head = dictionaryNode2;
				}
				this.count++;
			}
		}

		// Token: 0x17000839 RID: 2105
		// (get) Token: 0x06003718 RID: 14104 RVA: 0x000D34FB File Offset: 0x000D16FB
		public int Count
		{
			get
			{
				return this.count;
			}
		}

		// Token: 0x1700083A RID: 2106
		// (get) Token: 0x06003719 RID: 14105 RVA: 0x000D3503 File Offset: 0x000D1703
		public ICollection Keys
		{
			get
			{
				return new ListDictionaryInternal.NodeKeyValueCollection(this, true);
			}
		}

		// Token: 0x1700083B RID: 2107
		// (get) Token: 0x0600371A RID: 14106 RVA: 0x000D350C File Offset: 0x000D170C
		public bool IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700083C RID: 2108
		// (get) Token: 0x0600371B RID: 14107 RVA: 0x000D350F File Offset: 0x000D170F
		public bool IsFixedSize
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700083D RID: 2109
		// (get) Token: 0x0600371C RID: 14108 RVA: 0x000D3512 File Offset: 0x000D1712
		public bool IsSynchronized
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700083E RID: 2110
		// (get) Token: 0x0600371D RID: 14109 RVA: 0x000D3515 File Offset: 0x000D1715
		public object SyncRoot
		{
			get
			{
				if (this._syncRoot == null)
				{
					Interlocked.CompareExchange<object>(ref this._syncRoot, new object(), null);
				}
				return this._syncRoot;
			}
		}

		// Token: 0x1700083F RID: 2111
		// (get) Token: 0x0600371E RID: 14110 RVA: 0x000D3537 File Offset: 0x000D1737
		public ICollection Values
		{
			get
			{
				return new ListDictionaryInternal.NodeKeyValueCollection(this, false);
			}
		}

		// Token: 0x0600371F RID: 14111 RVA: 0x000D3540 File Offset: 0x000D1740
		public void Add(object key, object value)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key", Environment.GetResourceString("ArgumentNull_Key"));
			}
			if (!key.GetType().IsSerializable)
			{
				throw new ArgumentException(Environment.GetResourceString("Argument_NotSerializable"), "key");
			}
			if (value != null && !value.GetType().IsSerializable)
			{
				throw new ArgumentException(Environment.GetResourceString("Argument_NotSerializable"), "value");
			}
			this.version++;
			ListDictionaryInternal.DictionaryNode dictionaryNode = null;
			ListDictionaryInternal.DictionaryNode next;
			for (next = this.head; next != null; next = next.next)
			{
				if (next.key.Equals(key))
				{
					throw new ArgumentException(Environment.GetResourceString("Argument_AddingDuplicate__", new object[]
					{
						next.key,
						key
					}));
				}
				dictionaryNode = next;
			}
			if (next != null)
			{
				next.value = value;
				return;
			}
			ListDictionaryInternal.DictionaryNode dictionaryNode2 = new ListDictionaryInternal.DictionaryNode();
			dictionaryNode2.key = key;
			dictionaryNode2.value = value;
			if (dictionaryNode != null)
			{
				dictionaryNode.next = dictionaryNode2;
			}
			else
			{
				this.head = dictionaryNode2;
			}
			this.count++;
		}

		// Token: 0x06003720 RID: 14112 RVA: 0x000D3642 File Offset: 0x000D1842
		public void Clear()
		{
			this.count = 0;
			this.head = null;
			this.version++;
		}

		// Token: 0x06003721 RID: 14113 RVA: 0x000D3660 File Offset: 0x000D1860
		public bool Contains(object key)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key", Environment.GetResourceString("ArgumentNull_Key"));
			}
			for (ListDictionaryInternal.DictionaryNode next = this.head; next != null; next = next.next)
			{
				if (next.key.Equals(key))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x06003722 RID: 14114 RVA: 0x000D36AC File Offset: 0x000D18AC
		public void CopyTo(Array array, int index)
		{
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			if (array.Rank != 1)
			{
				throw new ArgumentException(Environment.GetResourceString("Arg_RankMultiDimNotSupported"));
			}
			if (index < 0)
			{
				throw new ArgumentOutOfRangeException("index", Environment.GetResourceString("ArgumentOutOfRange_NeedNonNegNum"));
			}
			if (array.Length - index < this.Count)
			{
				throw new ArgumentException(Environment.GetResourceString("ArgumentOutOfRange_Index"), "index");
			}
			for (ListDictionaryInternal.DictionaryNode next = this.head; next != null; next = next.next)
			{
				array.SetValue(new DictionaryEntry(next.key, next.value), index);
				index++;
			}
		}

		// Token: 0x06003723 RID: 14115 RVA: 0x000D3753 File Offset: 0x000D1953
		public IDictionaryEnumerator GetEnumerator()
		{
			return new ListDictionaryInternal.NodeEnumerator(this);
		}

		// Token: 0x06003724 RID: 14116 RVA: 0x000D375B File Offset: 0x000D195B
		IEnumerator IEnumerable.GetEnumerator()
		{
			return new ListDictionaryInternal.NodeEnumerator(this);
		}

		// Token: 0x06003725 RID: 14117 RVA: 0x000D3764 File Offset: 0x000D1964
		public void Remove(object key)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key", Environment.GetResourceString("ArgumentNull_Key"));
			}
			this.version++;
			ListDictionaryInternal.DictionaryNode dictionaryNode = null;
			ListDictionaryInternal.DictionaryNode next = this.head;
			while (next != null && !next.key.Equals(key))
			{
				dictionaryNode = next;
				next = next.next;
			}
			if (next == null)
			{
				return;
			}
			if (next == this.head)
			{
				this.head = next.next;
			}
			else
			{
				dictionaryNode.next = next.next;
			}
			this.count--;
		}

		// Token: 0x04001822 RID: 6178
		private ListDictionaryInternal.DictionaryNode head;

		// Token: 0x04001823 RID: 6179
		private int version;

		// Token: 0x04001824 RID: 6180
		private int count;

		// Token: 0x04001825 RID: 6181
		[NonSerialized]
		private object _syncRoot;

		// Token: 0x02000B7B RID: 2939
		private class NodeEnumerator : IDictionaryEnumerator, IEnumerator
		{
			// Token: 0x06006CA4 RID: 27812 RVA: 0x00176D00 File Offset: 0x00174F00
			public NodeEnumerator(ListDictionaryInternal list)
			{
				this.list = list;
				this.version = list.version;
				this.start = true;
				this.current = null;
			}

			// Token: 0x1700128A RID: 4746
			// (get) Token: 0x06006CA5 RID: 27813 RVA: 0x00176D29 File Offset: 0x00174F29
			public object Current
			{
				get
				{
					return this.Entry;
				}
			}

			// Token: 0x1700128B RID: 4747
			// (get) Token: 0x06006CA6 RID: 27814 RVA: 0x00176D36 File Offset: 0x00174F36
			public DictionaryEntry Entry
			{
				get
				{
					if (this.current == null)
					{
						throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_EnumOpCantHappen"));
					}
					return new DictionaryEntry(this.current.key, this.current.value);
				}
			}

			// Token: 0x1700128C RID: 4748
			// (get) Token: 0x06006CA7 RID: 27815 RVA: 0x00176D6B File Offset: 0x00174F6B
			public object Key
			{
				get
				{
					if (this.current == null)
					{
						throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_EnumOpCantHappen"));
					}
					return this.current.key;
				}
			}

			// Token: 0x1700128D RID: 4749
			// (get) Token: 0x06006CA8 RID: 27816 RVA: 0x00176D90 File Offset: 0x00174F90
			public object Value
			{
				get
				{
					if (this.current == null)
					{
						throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_EnumOpCantHappen"));
					}
					return this.current.value;
				}
			}

			// Token: 0x06006CA9 RID: 27817 RVA: 0x00176DB8 File Offset: 0x00174FB8
			public bool MoveNext()
			{
				if (this.version != this.list.version)
				{
					throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_EnumFailedVersion"));
				}
				if (this.start)
				{
					this.current = this.list.head;
					this.start = false;
				}
				else if (this.current != null)
				{
					this.current = this.current.next;
				}
				return this.current != null;
			}

			// Token: 0x06006CAA RID: 27818 RVA: 0x00176E2C File Offset: 0x0017502C
			public void Reset()
			{
				if (this.version != this.list.version)
				{
					throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_EnumFailedVersion"));
				}
				this.start = true;
				this.current = null;
			}

			// Token: 0x04003471 RID: 13425
			private ListDictionaryInternal list;

			// Token: 0x04003472 RID: 13426
			private ListDictionaryInternal.DictionaryNode current;

			// Token: 0x04003473 RID: 13427
			private int version;

			// Token: 0x04003474 RID: 13428
			private bool start;
		}

		// Token: 0x02000B7C RID: 2940
		private class NodeKeyValueCollection : ICollection, IEnumerable
		{
			// Token: 0x06006CAB RID: 27819 RVA: 0x00176E5F File Offset: 0x0017505F
			public NodeKeyValueCollection(ListDictionaryInternal list, bool isKeys)
			{
				this.list = list;
				this.isKeys = isKeys;
			}

			// Token: 0x06006CAC RID: 27820 RVA: 0x00176E78 File Offset: 0x00175078
			void ICollection.CopyTo(Array array, int index)
			{
				if (array == null)
				{
					throw new ArgumentNullException("array");
				}
				if (array.Rank != 1)
				{
					throw new ArgumentException(Environment.GetResourceString("Arg_RankMultiDimNotSupported"));
				}
				if (index < 0)
				{
					throw new ArgumentOutOfRangeException("index", Environment.GetResourceString("ArgumentOutOfRange_NeedNonNegNum"));
				}
				if (array.Length - index < this.list.Count)
				{
					throw new ArgumentException(Environment.GetResourceString("ArgumentOutOfRange_Index"), "index");
				}
				for (ListDictionaryInternal.DictionaryNode dictionaryNode = this.list.head; dictionaryNode != null; dictionaryNode = dictionaryNode.next)
				{
					array.SetValue(this.isKeys ? dictionaryNode.key : dictionaryNode.value, index);
					index++;
				}
			}

			// Token: 0x1700128E RID: 4750
			// (get) Token: 0x06006CAD RID: 27821 RVA: 0x00176F2C File Offset: 0x0017512C
			int ICollection.Count
			{
				get
				{
					int num = 0;
					for (ListDictionaryInternal.DictionaryNode dictionaryNode = this.list.head; dictionaryNode != null; dictionaryNode = dictionaryNode.next)
					{
						num++;
					}
					return num;
				}
			}

			// Token: 0x1700128F RID: 4751
			// (get) Token: 0x06006CAE RID: 27822 RVA: 0x00176F58 File Offset: 0x00175158
			bool ICollection.IsSynchronized
			{
				get
				{
					return false;
				}
			}

			// Token: 0x17001290 RID: 4752
			// (get) Token: 0x06006CAF RID: 27823 RVA: 0x00176F5B File Offset: 0x0017515B
			object ICollection.SyncRoot
			{
				get
				{
					return this.list.SyncRoot;
				}
			}

			// Token: 0x06006CB0 RID: 27824 RVA: 0x00176F68 File Offset: 0x00175168
			IEnumerator IEnumerable.GetEnumerator()
			{
				return new ListDictionaryInternal.NodeKeyValueCollection.NodeKeyValueEnumerator(this.list, this.isKeys);
			}

			// Token: 0x04003475 RID: 13429
			private ListDictionaryInternal list;

			// Token: 0x04003476 RID: 13430
			private bool isKeys;

			// Token: 0x02000CCA RID: 3274
			private class NodeKeyValueEnumerator : IEnumerator
			{
				// Token: 0x060070B9 RID: 28857 RVA: 0x00183E83 File Offset: 0x00182083
				public NodeKeyValueEnumerator(ListDictionaryInternal list, bool isKeys)
				{
					this.list = list;
					this.isKeys = isKeys;
					this.version = list.version;
					this.start = true;
					this.current = null;
				}

				// Token: 0x1700136A RID: 4970
				// (get) Token: 0x060070BA RID: 28858 RVA: 0x00183EB3 File Offset: 0x001820B3
				public object Current
				{
					get
					{
						if (this.current == null)
						{
							throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_EnumOpCantHappen"));
						}
						if (!this.isKeys)
						{
							return this.current.value;
						}
						return this.current.key;
					}
				}

				// Token: 0x060070BB RID: 28859 RVA: 0x00183EEC File Offset: 0x001820EC
				public bool MoveNext()
				{
					if (this.version != this.list.version)
					{
						throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_EnumFailedVersion"));
					}
					if (this.start)
					{
						this.current = this.list.head;
						this.start = false;
					}
					else if (this.current != null)
					{
						this.current = this.current.next;
					}
					return this.current != null;
				}

				// Token: 0x060070BC RID: 28860 RVA: 0x00183F60 File Offset: 0x00182160
				public void Reset()
				{
					if (this.version != this.list.version)
					{
						throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_EnumFailedVersion"));
					}
					this.start = true;
					this.current = null;
				}

				// Token: 0x04003846 RID: 14406
				private ListDictionaryInternal list;

				// Token: 0x04003847 RID: 14407
				private ListDictionaryInternal.DictionaryNode current;

				// Token: 0x04003848 RID: 14408
				private int version;

				// Token: 0x04003849 RID: 14409
				private bool isKeys;

				// Token: 0x0400384A RID: 14410
				private bool start;
			}
		}

		// Token: 0x02000B7D RID: 2941
		[Serializable]
		private class DictionaryNode
		{
			// Token: 0x04003477 RID: 13431
			public object key;

			// Token: 0x04003478 RID: 13432
			public object value;

			// Token: 0x04003479 RID: 13433
			public ListDictionaryInternal.DictionaryNode next;
		}
	}
}
