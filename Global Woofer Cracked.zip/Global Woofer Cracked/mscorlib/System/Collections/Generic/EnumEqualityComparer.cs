﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security;

namespace System.Collections.Generic
{
	// Token: 0x02000498 RID: 1176
	[Serializable]
	internal class EnumEqualityComparer<T> : EqualityComparer<T>, ISerializable where T : struct
	{
		// Token: 0x0600396D RID: 14701 RVA: 0x000DAB0C File Offset: 0x000D8D0C
		public override bool Equals(T x, T y)
		{
			int num = JitHelpers.UnsafeEnumCast<T>(x);
			int num2 = JitHelpers.UnsafeEnumCast<T>(y);
			return num == num2;
		}

		// Token: 0x0600396E RID: 14702 RVA: 0x000DAB2C File Offset: 0x000D8D2C
		public override int GetHashCode(T obj)
		{
			return JitHelpers.UnsafeEnumCast<T>(obj).GetHashCode();
		}

		// Token: 0x0600396F RID: 14703 RVA: 0x000DAB47 File Offset: 0x000D8D47
		public EnumEqualityComparer()
		{
		}

		// Token: 0x06003970 RID: 14704 RVA: 0x000DAB4F File Offset: 0x000D8D4F
		protected EnumEqualityComparer(SerializationInfo information, StreamingContext context)
		{
		}

		// Token: 0x06003971 RID: 14705 RVA: 0x000DAB57 File Offset: 0x000D8D57
		[SecurityCritical]
		public void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			if (Type.GetTypeCode(Enum.GetUnderlyingType(typeof(T))) != TypeCode.Int32)
			{
				info.SetType(typeof(ObjectEqualityComparer<T>));
			}
		}

		// Token: 0x06003972 RID: 14706 RVA: 0x000DAB84 File Offset: 0x000D8D84
		public override bool Equals(object obj)
		{
			EnumEqualityComparer<T> enumEqualityComparer = obj as EnumEqualityComparer<T>;
			return enumEqualityComparer != null;
		}

		// Token: 0x06003973 RID: 14707 RVA: 0x000DAB9C File Offset: 0x000D8D9C
		public override int GetHashCode()
		{
			return base.GetType().Name.GetHashCode();
		}
	}
}
