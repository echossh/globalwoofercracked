﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x020004B0 RID: 1200
	internal interface IArraySortHelper<TKey>
	{
		// Token: 0x06003A0C RID: 14860
		void Sort(TKey[] keys, int index, int length, IComparer<TKey> comparer);

		// Token: 0x06003A0D RID: 14861
		int BinarySearch(TKey[] keys, int index, int length, TKey value, IComparer<TKey> comparer);
	}
}
