﻿using System;
using System.Diagnostics;

namespace System.Collections.Generic
{
	// Token: 0x020004A0 RID: 1184
	internal sealed class Mscorlib_DictionaryValueCollectionDebugView<TKey, TValue>
	{
		// Token: 0x06003995 RID: 14741 RVA: 0x000DAEE8 File Offset: 0x000D90E8
		public Mscorlib_DictionaryValueCollectionDebugView(ICollection<TValue> collection)
		{
			if (collection == null)
			{
				ThrowHelper.ThrowArgumentNullException(ExceptionArgument.collection);
			}
			this.collection = collection;
		}

		// Token: 0x170008CC RID: 2252
		// (get) Token: 0x06003996 RID: 14742 RVA: 0x000DAF00 File Offset: 0x000D9100
		[DebuggerBrowsable(DebuggerBrowsableState.RootHidden)]
		public TValue[] Items
		{
			get
			{
				TValue[] array = new TValue[this.collection.Count];
				this.collection.CopyTo(array, 0);
				return array;
			}
		}

		// Token: 0x0400189A RID: 6298
		private ICollection<TValue> collection;
	}
}
