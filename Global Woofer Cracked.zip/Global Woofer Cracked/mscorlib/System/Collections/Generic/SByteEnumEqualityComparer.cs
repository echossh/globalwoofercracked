﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;

namespace System.Collections.Generic
{
	// Token: 0x02000499 RID: 1177
	[Serializable]
	internal sealed class SByteEnumEqualityComparer<T> : EnumEqualityComparer<T>, ISerializable where T : struct
	{
		// Token: 0x06003974 RID: 14708 RVA: 0x000DABAE File Offset: 0x000D8DAE
		public SByteEnumEqualityComparer()
		{
		}

		// Token: 0x06003975 RID: 14709 RVA: 0x000DABB6 File Offset: 0x000D8DB6
		public SByteEnumEqualityComparer(SerializationInfo information, StreamingContext context)
		{
		}

		// Token: 0x06003976 RID: 14710 RVA: 0x000DABC0 File Offset: 0x000D8DC0
		public override int GetHashCode(T obj)
		{
			int num = JitHelpers.UnsafeEnumCast<T>(obj);
			return ((sbyte)num).GetHashCode();
		}
	}
}
