﻿using System;
using System.Diagnostics;

namespace System.Collections.Generic
{
	// Token: 0x0200049F RID: 1183
	internal sealed class Mscorlib_DictionaryKeyCollectionDebugView<TKey, TValue>
	{
		// Token: 0x06003993 RID: 14739 RVA: 0x000DAEA4 File Offset: 0x000D90A4
		public Mscorlib_DictionaryKeyCollectionDebugView(ICollection<TKey> collection)
		{
			if (collection == null)
			{
				ThrowHelper.ThrowArgumentNullException(ExceptionArgument.collection);
			}
			this.collection = collection;
		}

		// Token: 0x170008CB RID: 2251
		// (get) Token: 0x06003994 RID: 14740 RVA: 0x000DAEBC File Offset: 0x000D90BC
		[DebuggerBrowsable(DebuggerBrowsableState.RootHidden)]
		public TKey[] Items
		{
			get
			{
				TKey[] array = new TKey[this.collection.Count];
				this.collection.CopyTo(array, 0);
				return array;
			}
		}

		// Token: 0x04001899 RID: 6297
		private ICollection<TKey> collection;
	}
}
