﻿using System;
using System.Diagnostics;

namespace System.Collections.Generic
{
	// Token: 0x020004A1 RID: 1185
	internal sealed class Mscorlib_DictionaryDebugView<K, V>
	{
		// Token: 0x06003997 RID: 14743 RVA: 0x000DAF2C File Offset: 0x000D912C
		public Mscorlib_DictionaryDebugView(IDictionary<K, V> dictionary)
		{
			if (dictionary == null)
			{
				ThrowHelper.ThrowArgumentNullException(ExceptionArgument.dictionary);
			}
			this.dict = dictionary;
		}

		// Token: 0x170008CD RID: 2253
		// (get) Token: 0x06003998 RID: 14744 RVA: 0x000DAF44 File Offset: 0x000D9144
		[DebuggerBrowsable(DebuggerBrowsableState.RootHidden)]
		public KeyValuePair<K, V>[] Items
		{
			get
			{
				KeyValuePair<K, V>[] array = new KeyValuePair<K, V>[this.dict.Count];
				this.dict.CopyTo(array, 0);
				return array;
			}
		}

		// Token: 0x0400189B RID: 6299
		private IDictionary<K, V> dict;
	}
}
