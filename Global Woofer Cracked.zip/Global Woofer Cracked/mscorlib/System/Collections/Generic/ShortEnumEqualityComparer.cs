﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;

namespace System.Collections.Generic
{
	// Token: 0x0200049A RID: 1178
	[Serializable]
	internal sealed class ShortEnumEqualityComparer<T> : EnumEqualityComparer<T>, ISerializable where T : struct
	{
		// Token: 0x06003977 RID: 14711 RVA: 0x000DABDE File Offset: 0x000D8DDE
		public ShortEnumEqualityComparer()
		{
		}

		// Token: 0x06003978 RID: 14712 RVA: 0x000DABE6 File Offset: 0x000D8DE6
		public ShortEnumEqualityComparer(SerializationInfo information, StreamingContext context)
		{
		}

		// Token: 0x06003979 RID: 14713 RVA: 0x000DABF0 File Offset: 0x000D8DF0
		public override int GetHashCode(T obj)
		{
			int num = JitHelpers.UnsafeEnumCast<T>(obj);
			return ((short)num).GetHashCode();
		}
	}
}
