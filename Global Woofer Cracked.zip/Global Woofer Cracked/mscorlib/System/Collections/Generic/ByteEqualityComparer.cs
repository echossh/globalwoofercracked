﻿using System;
using System.Security;

namespace System.Collections.Generic
{
	// Token: 0x02000497 RID: 1175
	[Serializable]
	internal class ByteEqualityComparer : EqualityComparer<byte>
	{
		// Token: 0x06003966 RID: 14694 RVA: 0x000DAA0A File Offset: 0x000D8C0A
		public override bool Equals(byte x, byte y)
		{
			return x == y;
		}

		// Token: 0x06003967 RID: 14695 RVA: 0x000DAA10 File Offset: 0x000D8C10
		public override int GetHashCode(byte b)
		{
			return b.GetHashCode();
		}

		// Token: 0x06003968 RID: 14696 RVA: 0x000DAA1C File Offset: 0x000D8C1C
		[SecuritySafeCritical]
		internal unsafe override int IndexOf(byte[] array, byte value, int startIndex, int count)
		{
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			if (startIndex < 0)
			{
				throw new ArgumentOutOfRangeException("startIndex", Environment.GetResourceString("ArgumentOutOfRange_Index"));
			}
			if (count < 0)
			{
				throw new ArgumentOutOfRangeException("count", Environment.GetResourceString("ArgumentOutOfRange_Count"));
			}
			if (count > array.Length - startIndex)
			{
				throw new ArgumentException(Environment.GetResourceString("Argument_InvalidOffLen"));
			}
			if (count == 0)
			{
				return -1;
			}
			byte* src;
			if (array == null || array.Length == 0)
			{
				src = null;
			}
			else
			{
				src = &array[0];
			}
			return Buffer.IndexOfByte(src, value, startIndex, count);
		}

		// Token: 0x06003969 RID: 14697 RVA: 0x000DAAAC File Offset: 0x000D8CAC
		internal override int LastIndexOf(byte[] array, byte value, int startIndex, int count)
		{
			int num = startIndex - count + 1;
			for (int i = startIndex; i >= num; i--)
			{
				if (array[i] == value)
				{
					return i;
				}
			}
			return -1;
		}

		// Token: 0x0600396A RID: 14698 RVA: 0x000DAAD8 File Offset: 0x000D8CD8
		public override bool Equals(object obj)
		{
			ByteEqualityComparer byteEqualityComparer = obj as ByteEqualityComparer;
			return byteEqualityComparer != null;
		}

		// Token: 0x0600396B RID: 14699 RVA: 0x000DAAF0 File Offset: 0x000D8CF0
		public override int GetHashCode()
		{
			return base.GetType().Name.GetHashCode();
		}
	}
}
