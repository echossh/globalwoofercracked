﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x02000496 RID: 1174
	[Serializable]
	internal class ObjectEqualityComparer<T> : EqualityComparer<T>
	{
		// Token: 0x0600395F RID: 14687 RVA: 0x000DA8A2 File Offset: 0x000D8AA2
		public override bool Equals(T x, T y)
		{
			if (x != null)
			{
				return y != null && x.Equals(y);
			}
			return y == null;
		}

		// Token: 0x06003960 RID: 14688 RVA: 0x000DA8D5 File Offset: 0x000D8AD5
		public override int GetHashCode(T obj)
		{
			if (obj == null)
			{
				return 0;
			}
			return obj.GetHashCode();
		}

		// Token: 0x06003961 RID: 14689 RVA: 0x000DA8F0 File Offset: 0x000D8AF0
		internal override int IndexOf(T[] array, T value, int startIndex, int count)
		{
			int num = startIndex + count;
			if (value == null)
			{
				for (int i = startIndex; i < num; i++)
				{
					if (array[i] == null)
					{
						return i;
					}
				}
			}
			else
			{
				for (int j = startIndex; j < num; j++)
				{
					if (array[j] != null && array[j].Equals(value))
					{
						return j;
					}
				}
			}
			return -1;
		}

		// Token: 0x06003962 RID: 14690 RVA: 0x000DA964 File Offset: 0x000D8B64
		internal override int LastIndexOf(T[] array, T value, int startIndex, int count)
		{
			int num = startIndex - count + 1;
			if (value == null)
			{
				for (int i = startIndex; i >= num; i--)
				{
					if (array[i] == null)
					{
						return i;
					}
				}
			}
			else
			{
				for (int j = startIndex; j >= num; j--)
				{
					if (array[j] != null && array[j].Equals(value))
					{
						return j;
					}
				}
			}
			return -1;
		}

		// Token: 0x06003963 RID: 14691 RVA: 0x000DA9D8 File Offset: 0x000D8BD8
		public override bool Equals(object obj)
		{
			ObjectEqualityComparer<T> objectEqualityComparer = obj as ObjectEqualityComparer<T>;
			return objectEqualityComparer != null;
		}

		// Token: 0x06003964 RID: 14692 RVA: 0x000DA9F0 File Offset: 0x000D8BF0
		public override int GetHashCode()
		{
			return base.GetType().Name.GetHashCode();
		}
	}
}
