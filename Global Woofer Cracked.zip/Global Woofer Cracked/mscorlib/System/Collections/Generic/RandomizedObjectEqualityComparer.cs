﻿using System;
using System.Security;

namespace System.Collections.Generic
{
	// Token: 0x0200049D RID: 1181
	internal sealed class RandomizedObjectEqualityComparer : IEqualityComparer, IWellKnownStringEqualityComparer
	{
		// Token: 0x0600398A RID: 14730 RVA: 0x000DADA6 File Offset: 0x000D8FA6
		public RandomizedObjectEqualityComparer()
		{
			this._entropy = HashHelpers.GetEntropy();
		}

		// Token: 0x0600398B RID: 14731 RVA: 0x000DADB9 File Offset: 0x000D8FB9
		public bool Equals(object x, object y)
		{
			if (x != null)
			{
				return y != null && x.Equals(y);
			}
			return y == null;
		}

		// Token: 0x0600398C RID: 14732 RVA: 0x000DADD4 File Offset: 0x000D8FD4
		[SecuritySafeCritical]
		public int GetHashCode(object obj)
		{
			if (obj == null)
			{
				return 0;
			}
			string text = obj as string;
			if (text != null)
			{
				return string.InternalMarvin32HashString(text, text.Length, this._entropy);
			}
			return obj.GetHashCode();
		}

		// Token: 0x0600398D RID: 14733 RVA: 0x000DAE0C File Offset: 0x000D900C
		public override bool Equals(object obj)
		{
			RandomizedObjectEqualityComparer randomizedObjectEqualityComparer = obj as RandomizedObjectEqualityComparer;
			return randomizedObjectEqualityComparer != null && this._entropy == randomizedObjectEqualityComparer._entropy;
		}

		// Token: 0x0600398E RID: 14734 RVA: 0x000DAE33 File Offset: 0x000D9033
		public override int GetHashCode()
		{
			return base.GetType().Name.GetHashCode() ^ (int)(this._entropy & 2147483647L);
		}

		// Token: 0x0600398F RID: 14735 RVA: 0x000DAE54 File Offset: 0x000D9054
		IEqualityComparer IWellKnownStringEqualityComparer.GetRandomizedEqualityComparer()
		{
			return new RandomizedObjectEqualityComparer();
		}

		// Token: 0x06003990 RID: 14736 RVA: 0x000DAE5B File Offset: 0x000D905B
		IEqualityComparer IWellKnownStringEqualityComparer.GetEqualityComparerForSerialization()
		{
			return null;
		}

		// Token: 0x04001897 RID: 6295
		private long _entropy;
	}
}
