﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x02000490 RID: 1168
	[Serializable]
	internal class ObjectComparer<T> : Comparer<T>
	{
		// Token: 0x0600390B RID: 14603 RVA: 0x000D9406 File Offset: 0x000D7606
		public override int Compare(T x, T y)
		{
			return Comparer.Default.Compare(x, y);
		}

		// Token: 0x0600390C RID: 14604 RVA: 0x000D9420 File Offset: 0x000D7620
		public override bool Equals(object obj)
		{
			ObjectComparer<T> objectComparer = obj as ObjectComparer<T>;
			return objectComparer != null;
		}

		// Token: 0x0600390D RID: 14605 RVA: 0x000D9438 File Offset: 0x000D7638
		public override int GetHashCode()
		{
			return base.GetType().Name.GetHashCode();
		}
	}
}
