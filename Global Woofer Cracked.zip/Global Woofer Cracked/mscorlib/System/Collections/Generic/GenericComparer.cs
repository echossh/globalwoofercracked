﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x0200048E RID: 1166
	[Serializable]
	internal class GenericComparer<T> : Comparer<T> where T : IComparable<T>
	{
		// Token: 0x06003903 RID: 14595 RVA: 0x000D9333 File Offset: 0x000D7533
		public override int Compare(T x, T y)
		{
			if (x != null)
			{
				if (y != null)
				{
					return x.CompareTo(y);
				}
				return 1;
			}
			else
			{
				if (y != null)
				{
					return -1;
				}
				return 0;
			}
		}

		// Token: 0x06003904 RID: 14596 RVA: 0x000D9364 File Offset: 0x000D7564
		public override bool Equals(object obj)
		{
			GenericComparer<T> genericComparer = obj as GenericComparer<T>;
			return genericComparer != null;
		}

		// Token: 0x06003905 RID: 14597 RVA: 0x000D937C File Offset: 0x000D757C
		public override int GetHashCode()
		{
			return base.GetType().Name.GetHashCode();
		}
	}
}
