﻿using System;

namespace System.Collections.Generic
{
	// Token: 0x0200048F RID: 1167
	[Serializable]
	internal class NullableComparer<T> : Comparer<T?> where T : struct, IComparable<T>
	{
		// Token: 0x06003907 RID: 14599 RVA: 0x000D9396 File Offset: 0x000D7596
		public override int Compare(T? x, T? y)
		{
			if (x != null)
			{
				if (y != null)
				{
					return x.value.CompareTo(y.value);
				}
				return 1;
			}
			else
			{
				if (y != null)
				{
					return -1;
				}
				return 0;
			}
		}

		// Token: 0x06003908 RID: 14600 RVA: 0x000D93D4 File Offset: 0x000D75D4
		public override bool Equals(object obj)
		{
			NullableComparer<T> nullableComparer = obj as NullableComparer<T>;
			return nullableComparer != null;
		}

		// Token: 0x06003909 RID: 14601 RVA: 0x000D93EC File Offset: 0x000D75EC
		public override int GetHashCode()
		{
			return base.GetType().Name.GetHashCode();
		}
	}
}
