﻿using System;

namespace System.Collections
{
	// Token: 0x02000469 RID: 1129
	[Serializable]
	internal sealed class EmptyReadOnlyDictionaryInternal : IDictionary, ICollection, IEnumerable
	{
		// Token: 0x06003727 RID: 14119 RVA: 0x000D37F9 File Offset: 0x000D19F9
		IEnumerator IEnumerable.GetEnumerator()
		{
			return new EmptyReadOnlyDictionaryInternal.NodeEnumerator();
		}

		// Token: 0x06003728 RID: 14120 RVA: 0x000D3800 File Offset: 0x000D1A00
		public void CopyTo(Array array, int index)
		{
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			if (array.Rank != 1)
			{
				throw new ArgumentException(Environment.GetResourceString("Arg_RankMultiDimNotSupported"));
			}
			if (index < 0)
			{
				throw new ArgumentOutOfRangeException("index", Environment.GetResourceString("ArgumentOutOfRange_NeedNonNegNum"));
			}
			if (array.Length - index < this.Count)
			{
				throw new ArgumentException(Environment.GetResourceString("ArgumentOutOfRange_Index"), "index");
			}
		}

		// Token: 0x17000840 RID: 2112
		// (get) Token: 0x06003729 RID: 14121 RVA: 0x000D3872 File Offset: 0x000D1A72
		public int Count
		{
			get
			{
				return 0;
			}
		}

		// Token: 0x17000841 RID: 2113
		// (get) Token: 0x0600372A RID: 14122 RVA: 0x000D3875 File Offset: 0x000D1A75
		public object SyncRoot
		{
			get
			{
				return this;
			}
		}

		// Token: 0x17000842 RID: 2114
		// (get) Token: 0x0600372B RID: 14123 RVA: 0x000D3878 File Offset: 0x000D1A78
		public bool IsSynchronized
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000843 RID: 2115
		public object this[object key]
		{
			get
			{
				if (key == null)
				{
					throw new ArgumentNullException("key", Environment.GetResourceString("ArgumentNull_Key"));
				}
				return null;
			}
			set
			{
				if (key == null)
				{
					throw new ArgumentNullException("key", Environment.GetResourceString("ArgumentNull_Key"));
				}
				if (!key.GetType().IsSerializable)
				{
					throw new ArgumentException(Environment.GetResourceString("Argument_NotSerializable"), "key");
				}
				if (value != null && !value.GetType().IsSerializable)
				{
					throw new ArgumentException(Environment.GetResourceString("Argument_NotSerializable"), "value");
				}
				throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_ReadOnly"));
			}
		}

		// Token: 0x17000844 RID: 2116
		// (get) Token: 0x0600372E RID: 14126 RVA: 0x000D3913 File Offset: 0x000D1B13
		public ICollection Keys
		{
			get
			{
				return EmptyArray<object>.Value;
			}
		}

		// Token: 0x17000845 RID: 2117
		// (get) Token: 0x0600372F RID: 14127 RVA: 0x000D391A File Offset: 0x000D1B1A
		public ICollection Values
		{
			get
			{
				return EmptyArray<object>.Value;
			}
		}

		// Token: 0x06003730 RID: 14128 RVA: 0x000D3921 File Offset: 0x000D1B21
		public bool Contains(object key)
		{
			return false;
		}

		// Token: 0x06003731 RID: 14129 RVA: 0x000D3924 File Offset: 0x000D1B24
		public void Add(object key, object value)
		{
			if (key == null)
			{
				throw new ArgumentNullException("key", Environment.GetResourceString("ArgumentNull_Key"));
			}
			if (!key.GetType().IsSerializable)
			{
				throw new ArgumentException(Environment.GetResourceString("Argument_NotSerializable"), "key");
			}
			if (value != null && !value.GetType().IsSerializable)
			{
				throw new ArgumentException(Environment.GetResourceString("Argument_NotSerializable"), "value");
			}
			throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_ReadOnly"));
		}

		// Token: 0x06003732 RID: 14130 RVA: 0x000D399F File Offset: 0x000D1B9F
		public void Clear()
		{
			throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_ReadOnly"));
		}

		// Token: 0x17000846 RID: 2118
		// (get) Token: 0x06003733 RID: 14131 RVA: 0x000D39B0 File Offset: 0x000D1BB0
		public bool IsReadOnly
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000847 RID: 2119
		// (get) Token: 0x06003734 RID: 14132 RVA: 0x000D39B3 File Offset: 0x000D1BB3
		public bool IsFixedSize
		{
			get
			{
				return true;
			}
		}

		// Token: 0x06003735 RID: 14133 RVA: 0x000D39B6 File Offset: 0x000D1BB6
		public IDictionaryEnumerator GetEnumerator()
		{
			return new EmptyReadOnlyDictionaryInternal.NodeEnumerator();
		}

		// Token: 0x06003736 RID: 14134 RVA: 0x000D39BD File Offset: 0x000D1BBD
		public void Remove(object key)
		{
			throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_ReadOnly"));
		}

		// Token: 0x02000B7E RID: 2942
		private sealed class NodeEnumerator : IDictionaryEnumerator, IEnumerator
		{
			// Token: 0x06006CB3 RID: 27827 RVA: 0x00176F8B File Offset: 0x0017518B
			public bool MoveNext()
			{
				return false;
			}

			// Token: 0x17001291 RID: 4753
			// (get) Token: 0x06006CB4 RID: 27828 RVA: 0x00176F8E File Offset: 0x0017518E
			public object Current
			{
				get
				{
					throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_EnumOpCantHappen"));
				}
			}

			// Token: 0x06006CB5 RID: 27829 RVA: 0x00176F9F File Offset: 0x0017519F
			public void Reset()
			{
			}

			// Token: 0x17001292 RID: 4754
			// (get) Token: 0x06006CB6 RID: 27830 RVA: 0x00176FA1 File Offset: 0x001751A1
			public object Key
			{
				get
				{
					throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_EnumOpCantHappen"));
				}
			}

			// Token: 0x17001293 RID: 4755
			// (get) Token: 0x06006CB7 RID: 27831 RVA: 0x00176FB2 File Offset: 0x001751B2
			public object Value
			{
				get
				{
					throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_EnumOpCantHappen"));
				}
			}

			// Token: 0x17001294 RID: 4756
			// (get) Token: 0x06006CB8 RID: 27832 RVA: 0x00176FC3 File Offset: 0x001751C3
			public DictionaryEntry Entry
			{
				get
				{
					throw new InvalidOperationException(Environment.GetResourceString("InvalidOperation_EnumOpCantHappen"));
				}
			}
		}
	}
}
