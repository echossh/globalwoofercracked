﻿using System;

namespace System.Collections
{
	// Token: 0x02000467 RID: 1127
	[Serializable]
	internal class CompatibleComparer : IEqualityComparer
	{
		// Token: 0x0600370F RID: 14095 RVA: 0x000D3310 File Offset: 0x000D1510
		internal CompatibleComparer(IComparer comparer, IHashCodeProvider hashCodeProvider)
		{
			this._comparer = comparer;
			this._hcp = hashCodeProvider;
		}

		// Token: 0x06003710 RID: 14096 RVA: 0x000D3328 File Offset: 0x000D1528
		public int Compare(object a, object b)
		{
			if (a == b)
			{
				return 0;
			}
			if (a == null)
			{
				return -1;
			}
			if (b == null)
			{
				return 1;
			}
			if (this._comparer != null)
			{
				return this._comparer.Compare(a, b);
			}
			IComparable comparable = a as IComparable;
			if (comparable != null)
			{
				return comparable.CompareTo(b);
			}
			throw new ArgumentException(Environment.GetResourceString("Argument_ImplementIComparable"));
		}

		// Token: 0x06003711 RID: 14097 RVA: 0x000D337C File Offset: 0x000D157C
		public bool Equals(object a, object b)
		{
			return this.Compare(a, b) == 0;
		}

		// Token: 0x06003712 RID: 14098 RVA: 0x000D3389 File Offset: 0x000D1589
		public int GetHashCode(object obj)
		{
			if (obj == null)
			{
				throw new ArgumentNullException("obj");
			}
			if (this._hcp != null)
			{
				return this._hcp.GetHashCode(obj);
			}
			return obj.GetHashCode();
		}

		// Token: 0x17000836 RID: 2102
		// (get) Token: 0x06003713 RID: 14099 RVA: 0x000D33B4 File Offset: 0x000D15B4
		internal IComparer Comparer
		{
			get
			{
				return this._comparer;
			}
		}

		// Token: 0x17000837 RID: 2103
		// (get) Token: 0x06003714 RID: 14100 RVA: 0x000D33BC File Offset: 0x000D15BC
		internal IHashCodeProvider HashCodeProvider
		{
			get
			{
				return this._hcp;
			}
		}

		// Token: 0x04001820 RID: 6176
		private IComparer _comparer;

		// Token: 0x04001821 RID: 6177
		private IHashCodeProvider _hcp;
	}
}
