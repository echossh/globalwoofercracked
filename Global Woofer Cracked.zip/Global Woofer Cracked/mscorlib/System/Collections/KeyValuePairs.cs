﻿using System;
using System.Diagnostics;

namespace System.Collections
{
	// Token: 0x02000476 RID: 1142
	[DebuggerDisplay("{value}", Name = "[{key}]", Type = "")]
	internal class KeyValuePairs
	{
		// Token: 0x060037A4 RID: 14244 RVA: 0x000D5201 File Offset: 0x000D3401
		public KeyValuePairs(object key, object value)
		{
			this.value = value;
			this.key = key;
		}

		// Token: 0x17000865 RID: 2149
		// (get) Token: 0x060037A5 RID: 14245 RVA: 0x000D5217 File Offset: 0x000D3417
		public object Key
		{
			get
			{
				return this.key;
			}
		}

		// Token: 0x17000866 RID: 2150
		// (get) Token: 0x060037A6 RID: 14246 RVA: 0x000D521F File Offset: 0x000D341F
		public object Value
		{
			get
			{
				return this.value;
			}
		}

		// Token: 0x04001847 RID: 6215
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object key;

		// Token: 0x04001848 RID: 6216
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object value;
	}
}
