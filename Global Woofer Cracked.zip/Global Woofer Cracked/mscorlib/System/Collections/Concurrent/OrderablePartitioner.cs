﻿using System;
using System.Collections.Generic;
using System.Security.Permissions;

namespace System.Collections.Concurrent
{
	/// <summary>Represents a particular manner of splitting an orderable data source into multiple partitions.</summary>
	/// <typeparam name="TSource">Type of the elements in the collection.</typeparam>
	// Token: 0x02000485 RID: 1157
	[__DynamicallyInvokable]
	[HostProtection(SecurityAction.LinkDemand, Synchronization = true, ExternalThreading = true)]
	public abstract class OrderablePartitioner<TSource> : Partitioner<TSource>
	{
		/// <summary>Called from constructors in derived classes to initialize the <see cref="T:System.Collections.Concurrent.OrderablePartitioner`1" /> class with the specified constraints on the index keys.</summary>
		/// <param name="keysOrderedInEachPartition">Indicates whether the elements in each partition are yielded in the order of increasing keys.</param>
		/// <param name="keysOrderedAcrossPartitions">Indicates whether elements in an earlier partition always come before elements in a later partition. If true, each element in partition 0 has a smaller order key than any element in partition 1, each element in partition 1 has a smaller order key than any element in partition 2, and so on.</param>
		/// <param name="keysNormalized">Indicates whether keys are normalized. If true, all order keys are distinct integers in the range [0 .. numberOfElements-1]. If false, order keys must still be distinct, but only their relative order is considered, not their absolute values.</param>
		// Token: 0x0600386A RID: 14442 RVA: 0x000D7DA2 File Offset: 0x000D5FA2
		[__DynamicallyInvokable]
		protected OrderablePartitioner(bool keysOrderedInEachPartition, bool keysOrderedAcrossPartitions, bool keysNormalized)
		{
			this.KeysOrderedInEachPartition = keysOrderedInEachPartition;
			this.KeysOrderedAcrossPartitions = keysOrderedAcrossPartitions;
			this.KeysNormalized = keysNormalized;
		}

		/// <summary>Partitions the underlying collection into the specified number of orderable partitions.</summary>
		/// <param name="partitionCount">The number of partitions to create.</param>
		/// <returns>A list containing <paramref name="partitionCount" /> enumerators.</returns>
		// Token: 0x0600386B RID: 14443
		[__DynamicallyInvokable]
		public abstract IList<IEnumerator<KeyValuePair<long, TSource>>> GetOrderablePartitions(int partitionCount);

		/// <summary>Creates an object that can partition the underlying collection into a variable number of partitions.</summary>
		/// <returns>An object that can create partitions over the underlying data source.</returns>
		/// <exception cref="T:System.NotSupportedException">Dynamic partitioning is not supported by this partitioner.</exception>
		// Token: 0x0600386C RID: 14444 RVA: 0x000D7DBF File Offset: 0x000D5FBF
		[__DynamicallyInvokable]
		public virtual IEnumerable<KeyValuePair<long, TSource>> GetOrderableDynamicPartitions()
		{
			throw new NotSupportedException(Environment.GetResourceString("Partitioner_DynamicPartitionsNotSupported"));
		}

		/// <summary>Gets whether elements in each partition are yielded in the order of increasing keys.</summary>
		/// <returns>
		///   <see langword="true" /> if the elements in each partition are yielded in the order of increasing keys; otherwise, <see langword="false" />.</returns>
		// Token: 0x1700088C RID: 2188
		// (get) Token: 0x0600386D RID: 14445 RVA: 0x000D7DD0 File Offset: 0x000D5FD0
		// (set) Token: 0x0600386E RID: 14446 RVA: 0x000D7DD8 File Offset: 0x000D5FD8
		[__DynamicallyInvokable]
		public bool KeysOrderedInEachPartition { [__DynamicallyInvokable] get; private set; }

		/// <summary>Gets whether elements in an earlier partition always come before elements in a later partition.</summary>
		/// <returns>
		///   <see langword="true" /> if the elements in an earlier partition always come before elements in a later partition; otherwise, <see langword="false" />.</returns>
		// Token: 0x1700088D RID: 2189
		// (get) Token: 0x0600386F RID: 14447 RVA: 0x000D7DE1 File Offset: 0x000D5FE1
		// (set) Token: 0x06003870 RID: 14448 RVA: 0x000D7DE9 File Offset: 0x000D5FE9
		[__DynamicallyInvokable]
		public bool KeysOrderedAcrossPartitions { [__DynamicallyInvokable] get; private set; }

		/// <summary>Gets whether order keys are normalized.</summary>
		/// <returns>
		///   <see langword="true" /> if the keys are normalized; otherwise, <see langword="false" />.</returns>
		// Token: 0x1700088E RID: 2190
		// (get) Token: 0x06003871 RID: 14449 RVA: 0x000D7DF2 File Offset: 0x000D5FF2
		// (set) Token: 0x06003872 RID: 14450 RVA: 0x000D7DFA File Offset: 0x000D5FFA
		[__DynamicallyInvokable]
		public bool KeysNormalized { [__DynamicallyInvokable] get; private set; }

		/// <summary>Partitions the underlying collection into the given number of ordered partitions.</summary>
		/// <param name="partitionCount">The number of partitions to create.</param>
		/// <returns>A list containing <paramref name="partitionCount" /> enumerators.</returns>
		// Token: 0x06003873 RID: 14451 RVA: 0x000D7E04 File Offset: 0x000D6004
		[__DynamicallyInvokable]
		public override IList<IEnumerator<TSource>> GetPartitions(int partitionCount)
		{
			IList<IEnumerator<KeyValuePair<long, TSource>>> orderablePartitions = this.GetOrderablePartitions(partitionCount);
			if (orderablePartitions.Count != partitionCount)
			{
				throw new InvalidOperationException("OrderablePartitioner_GetPartitions_WrongNumberOfPartitions");
			}
			IEnumerator<TSource>[] array = new IEnumerator<!0>[partitionCount];
			for (int i = 0; i < partitionCount; i++)
			{
				array[i] = new OrderablePartitioner<TSource>.EnumeratorDropIndices(orderablePartitions[i]);
			}
			return array;
		}

		/// <summary>Creates an object that can partition the underlying collection into a variable number of partitions.</summary>
		/// <returns>An object that can create partitions over the underlying data source.</returns>
		/// <exception cref="T:System.NotSupportedException">Dynamic partitioning is not supported by the base class. It must be implemented in derived classes.</exception>
		// Token: 0x06003874 RID: 14452 RVA: 0x000D7E50 File Offset: 0x000D6050
		[__DynamicallyInvokable]
		public override IEnumerable<TSource> GetDynamicPartitions()
		{
			IEnumerable<KeyValuePair<long, TSource>> orderableDynamicPartitions = this.GetOrderableDynamicPartitions();
			return new OrderablePartitioner<TSource>.EnumerableDropIndices(orderableDynamicPartitions);
		}

		// Token: 0x02000B92 RID: 2962
		private class EnumerableDropIndices : IEnumerable<!0>, IEnumerable, IDisposable
		{
			// Token: 0x06006D58 RID: 27992 RVA: 0x00178DD7 File Offset: 0x00176FD7
			public EnumerableDropIndices(IEnumerable<KeyValuePair<long, TSource>> source)
			{
				this.m_source = source;
			}

			// Token: 0x06006D59 RID: 27993 RVA: 0x00178DE6 File Offset: 0x00176FE6
			public IEnumerator<TSource> GetEnumerator()
			{
				return new OrderablePartitioner<TSource>.EnumeratorDropIndices(this.m_source.GetEnumerator());
			}

			// Token: 0x06006D5A RID: 27994 RVA: 0x00178DF8 File Offset: 0x00176FF8
			IEnumerator IEnumerable.GetEnumerator()
			{
				return this.GetEnumerator();
			}

			// Token: 0x06006D5B RID: 27995 RVA: 0x00178E00 File Offset: 0x00177000
			public void Dispose()
			{
				IDisposable disposable = this.m_source as IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}

			// Token: 0x040034C2 RID: 13506
			private readonly IEnumerable<KeyValuePair<long, TSource>> m_source;
		}

		// Token: 0x02000B93 RID: 2963
		private class EnumeratorDropIndices : IEnumerator<!0>, IDisposable, IEnumerator
		{
			// Token: 0x06006D5C RID: 27996 RVA: 0x00178E22 File Offset: 0x00177022
			public EnumeratorDropIndices(IEnumerator<KeyValuePair<long, TSource>> source)
			{
				this.m_source = source;
			}

			// Token: 0x06006D5D RID: 27997 RVA: 0x00178E31 File Offset: 0x00177031
			public bool MoveNext()
			{
				return this.m_source.MoveNext();
			}

			// Token: 0x170012CE RID: 4814
			// (get) Token: 0x06006D5E RID: 27998 RVA: 0x00178E40 File Offset: 0x00177040
			public TSource Current
			{
				get
				{
					KeyValuePair<long, TSource> keyValuePair = this.m_source.Current;
					return keyValuePair.Value;
				}
			}

			// Token: 0x170012CF RID: 4815
			// (get) Token: 0x06006D5F RID: 27999 RVA: 0x00178E60 File Offset: 0x00177060
			object IEnumerator.Current
			{
				get
				{
					return this.Current;
				}
			}

			// Token: 0x06006D60 RID: 28000 RVA: 0x00178E6D File Offset: 0x0017706D
			public void Dispose()
			{
				this.m_source.Dispose();
			}

			// Token: 0x06006D61 RID: 28001 RVA: 0x00178E7A File Offset: 0x0017707A
			public void Reset()
			{
				this.m_source.Reset();
			}

			// Token: 0x040034C3 RID: 13507
			private readonly IEnumerator<KeyValuePair<long, TSource>> m_source;
		}
	}
}
