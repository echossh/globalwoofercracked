﻿using System;
using System.Diagnostics;

namespace System.Collections.Concurrent
{
	// Token: 0x0200047F RID: 1151
	internal sealed class SystemCollectionsConcurrent_ProducerConsumerCollectionDebugView<T>
	{
		// Token: 0x060037FE RID: 14334 RVA: 0x000D60F8 File Offset: 0x000D42F8
		public SystemCollectionsConcurrent_ProducerConsumerCollectionDebugView(IProducerConsumerCollection<T> collection)
		{
			if (collection == null)
			{
				throw new ArgumentNullException("collection");
			}
			this.m_collection = collection;
		}

		// Token: 0x17000876 RID: 2166
		// (get) Token: 0x060037FF RID: 14335 RVA: 0x000D6115 File Offset: 0x000D4315
		[DebuggerBrowsable(DebuggerBrowsableState.RootHidden)]
		public T[] Items
		{
			get
			{
				return this.m_collection.ToArray();
			}
		}

		// Token: 0x04001858 RID: 6232
		private IProducerConsumerCollection<T> m_collection;
	}
}
