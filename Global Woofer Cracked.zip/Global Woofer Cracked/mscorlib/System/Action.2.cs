﻿using System;
using System.Runtime.CompilerServices;

namespace System
{
	/// <summary>Encapsulates a method that has no parameters and does not return a value.</summary>
	// Token: 0x02000041 RID: 65
	// (Invoke) Token: 0x0600023C RID: 572
	[TypeForwardedFrom("System.Core, Version=3.5.0.0, Culture=Neutral, PublicKeyToken=b77a5c561934e089")]
	[__DynamicallyInvokable]
	public delegate void Action();
}
