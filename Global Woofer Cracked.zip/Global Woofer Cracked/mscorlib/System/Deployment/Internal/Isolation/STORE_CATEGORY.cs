﻿using System;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x0200064D RID: 1613
	internal struct STORE_CATEGORY
	{
		// Token: 0x04002138 RID: 8504
		public IDefinitionIdentity DefinitionIdentity;
	}
}
