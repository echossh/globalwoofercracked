﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000678 RID: 1656
	internal struct StoreOperationInstallDeployment
	{
		// Token: 0x06004EA8 RID: 20136 RVA: 0x00117ED3 File Offset: 0x001160D3
		public StoreOperationInstallDeployment(IDefinitionAppId App, StoreApplicationReference reference)
		{
			this = new StoreOperationInstallDeployment(App, true, reference);
		}

		// Token: 0x06004EA9 RID: 20137 RVA: 0x00117EE0 File Offset: 0x001160E0
		[SecuritySafeCritical]
		public StoreOperationInstallDeployment(IDefinitionAppId App, bool UninstallOthers, StoreApplicationReference reference)
		{
			this.Size = (uint)Marshal.SizeOf(typeof(StoreOperationInstallDeployment));
			this.Flags = StoreOperationInstallDeployment.OpFlags.Nothing;
			this.Application = App;
			if (UninstallOthers)
			{
				this.Flags |= StoreOperationInstallDeployment.OpFlags.UninstallOthers;
			}
			this.Reference = reference.ToIntPtr();
		}

		// Token: 0x06004EAA RID: 20138 RVA: 0x00117F2E File Offset: 0x0011612E
		[SecurityCritical]
		public void Destroy()
		{
			StoreApplicationReference.Destroy(this.Reference);
		}

		// Token: 0x04002181 RID: 8577
		[MarshalAs(UnmanagedType.U4)]
		public uint Size;

		// Token: 0x04002182 RID: 8578
		[MarshalAs(UnmanagedType.U4)]
		public StoreOperationInstallDeployment.OpFlags Flags;

		// Token: 0x04002183 RID: 8579
		[MarshalAs(UnmanagedType.Interface)]
		public IDefinitionAppId Application;

		// Token: 0x04002184 RID: 8580
		public IntPtr Reference;

		// Token: 0x02000C15 RID: 3093
		[Flags]
		public enum OpFlags
		{
			// Token: 0x04003684 RID: 13956
			Nothing = 0,
			// Token: 0x04003685 RID: 13957
			UninstallOthers = 1
		}

		// Token: 0x02000C16 RID: 3094
		public enum Disposition
		{
			// Token: 0x04003687 RID: 13959
			Failed,
			// Token: 0x04003688 RID: 13960
			AlreadyInstalled,
			// Token: 0x04003689 RID: 13961
			Installed
		}
	}
}
