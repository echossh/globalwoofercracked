﻿using System;
using System.Runtime.InteropServices;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000651 RID: 1617
	internal struct CATEGORY_SUBCATEGORY
	{
		// Token: 0x0400213D RID: 8509
		[MarshalAs(UnmanagedType.LPWStr)]
		public string Subcategory;
	}
}
