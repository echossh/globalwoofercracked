﻿using System;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x0200066E RID: 1646
	[Flags]
	internal enum IAPPIDAUTHORITY_ARE_REFERENCES_EQUAL_FLAGS
	{
		// Token: 0x0400215E RID: 8542
		IAPPIDAUTHORITY_ARE_REFERENCES_EQUAL_FLAG_IGNORE_VERSION = 1
	}
}
