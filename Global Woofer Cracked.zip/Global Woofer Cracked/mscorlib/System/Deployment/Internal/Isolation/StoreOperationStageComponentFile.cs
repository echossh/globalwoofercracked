﻿using System;
using System.Runtime.InteropServices;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000674 RID: 1652
	internal struct StoreOperationStageComponentFile
	{
		// Token: 0x06004E9D RID: 20125 RVA: 0x00117D68 File Offset: 0x00115F68
		public StoreOperationStageComponentFile(IDefinitionAppId App, string CompRelPath, string SrcFile)
		{
			this = new StoreOperationStageComponentFile(App, null, CompRelPath, SrcFile);
		}

		// Token: 0x06004E9E RID: 20126 RVA: 0x00117D74 File Offset: 0x00115F74
		public StoreOperationStageComponentFile(IDefinitionAppId App, IDefinitionIdentity Component, string CompRelPath, string SrcFile)
		{
			this.Size = (uint)Marshal.SizeOf(typeof(StoreOperationStageComponentFile));
			this.Flags = StoreOperationStageComponentFile.OpFlags.Nothing;
			this.Application = App;
			this.Component = Component;
			this.ComponentRelativePath = CompRelPath;
			this.SourceFilePath = SrcFile;
		}

		// Token: 0x06004E9F RID: 20127 RVA: 0x00117DAF File Offset: 0x00115FAF
		public void Destroy()
		{
		}

		// Token: 0x0400216D RID: 8557
		[MarshalAs(UnmanagedType.U4)]
		public uint Size;

		// Token: 0x0400216E RID: 8558
		[MarshalAs(UnmanagedType.U4)]
		public StoreOperationStageComponentFile.OpFlags Flags;

		// Token: 0x0400216F RID: 8559
		[MarshalAs(UnmanagedType.Interface)]
		public IDefinitionAppId Application;

		// Token: 0x04002170 RID: 8560
		[MarshalAs(UnmanagedType.Interface)]
		public IDefinitionIdentity Component;

		// Token: 0x04002171 RID: 8561
		[MarshalAs(UnmanagedType.LPWStr)]
		public string ComponentRelativePath;

		// Token: 0x04002172 RID: 8562
		[MarshalAs(UnmanagedType.LPWStr)]
		public string SourceFilePath;

		// Token: 0x02000C0E RID: 3086
		[Flags]
		public enum OpFlags
		{
			// Token: 0x04003670 RID: 13936
			Nothing = 0
		}

		// Token: 0x02000C0F RID: 3087
		public enum Disposition
		{
			// Token: 0x04003672 RID: 13938
			Failed,
			// Token: 0x04003673 RID: 13939
			Installed,
			// Token: 0x04003674 RID: 13940
			Refreshed,
			// Token: 0x04003675 RID: 13941
			AlreadyInstalled
		}
	}
}
