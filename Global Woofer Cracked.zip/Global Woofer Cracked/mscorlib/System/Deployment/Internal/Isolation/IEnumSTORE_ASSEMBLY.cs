﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000658 RID: 1624
	[Guid("a5c637bf-6eaa-4e5f-b535-55299657e33e")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[ComImport]
	internal interface IEnumSTORE_ASSEMBLY
	{
		// Token: 0x06004E21 RID: 20001
		[SecurityCritical]
		uint Next([In] uint celt, [MarshalAs(UnmanagedType.LPArray)] [Out] STORE_ASSEMBLY[] rgelt);

		// Token: 0x06004E22 RID: 20002
		[SecurityCritical]
		void Skip([In] uint celt);

		// Token: 0x06004E23 RID: 20003
		[SecurityCritical]
		void Reset();

		// Token: 0x06004E24 RID: 20004
		[SecurityCritical]
		IEnumSTORE_ASSEMBLY Clone();
	}
}
