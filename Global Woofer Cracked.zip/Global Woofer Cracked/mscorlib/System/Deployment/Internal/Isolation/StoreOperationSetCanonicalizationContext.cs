﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x0200067C RID: 1660
	internal struct StoreOperationSetCanonicalizationContext
	{
		// Token: 0x06004EB4 RID: 20148 RVA: 0x001181EA File Offset: 0x001163EA
		[SecurityCritical]
		public StoreOperationSetCanonicalizationContext(string Bases, string Exports)
		{
			this.Size = (uint)Marshal.SizeOf(typeof(StoreOperationSetCanonicalizationContext));
			this.Flags = StoreOperationSetCanonicalizationContext.OpFlags.Nothing;
			this.BaseAddressFilePath = Bases;
			this.ExportsFilePath = Exports;
		}

		// Token: 0x06004EB5 RID: 20149 RVA: 0x00118216 File Offset: 0x00116416
		public void Destroy()
		{
		}

		// Token: 0x04002195 RID: 8597
		[MarshalAs(UnmanagedType.U4)]
		public uint Size;

		// Token: 0x04002196 RID: 8598
		[MarshalAs(UnmanagedType.U4)]
		public StoreOperationSetCanonicalizationContext.OpFlags Flags;

		// Token: 0x04002197 RID: 8599
		[MarshalAs(UnmanagedType.LPWStr)]
		public string BaseAddressFilePath;

		// Token: 0x04002198 RID: 8600
		[MarshalAs(UnmanagedType.LPWStr)]
		public string ExportsFilePath;

		// Token: 0x02000C1B RID: 3099
		[Flags]
		public enum OpFlags
		{
			// Token: 0x04003696 RID: 13974
			Nothing = 0
		}
	}
}
