﻿using System;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000672 RID: 1650
	[Flags]
	internal enum ISTORE_ENUM_FILES_FLAGS
	{
		// Token: 0x04002166 RID: 8550
		ISTORE_ENUM_FILES_FLAG_INCLUDE_INSTALLED_FILES = 1,
		// Token: 0x04002167 RID: 8551
		ISTORE_ENUM_FILES_FLAG_INCLUDE_MISSING_FILES = 2
	}
}
