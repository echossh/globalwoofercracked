﻿using System;
using System.Runtime.InteropServices;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000673 RID: 1651
	internal struct StoreOperationStageComponent
	{
		// Token: 0x06004E9A RID: 20122 RVA: 0x00117D28 File Offset: 0x00115F28
		public void Destroy()
		{
		}

		// Token: 0x06004E9B RID: 20123 RVA: 0x00117D2A File Offset: 0x00115F2A
		public StoreOperationStageComponent(IDefinitionAppId app, string Manifest)
		{
			this = new StoreOperationStageComponent(app, null, Manifest);
		}

		// Token: 0x06004E9C RID: 20124 RVA: 0x00117D35 File Offset: 0x00115F35
		public StoreOperationStageComponent(IDefinitionAppId app, IDefinitionIdentity comp, string Manifest)
		{
			this.Size = (uint)Marshal.SizeOf(typeof(StoreOperationStageComponent));
			this.Flags = StoreOperationStageComponent.OpFlags.Nothing;
			this.Application = app;
			this.Component = comp;
			this.ManifestPath = Manifest;
		}

		// Token: 0x04002168 RID: 8552
		[MarshalAs(UnmanagedType.U4)]
		public uint Size;

		// Token: 0x04002169 RID: 8553
		[MarshalAs(UnmanagedType.U4)]
		public StoreOperationStageComponent.OpFlags Flags;

		// Token: 0x0400216A RID: 8554
		[MarshalAs(UnmanagedType.Interface)]
		public IDefinitionAppId Application;

		// Token: 0x0400216B RID: 8555
		[MarshalAs(UnmanagedType.Interface)]
		public IDefinitionIdentity Component;

		// Token: 0x0400216C RID: 8556
		[MarshalAs(UnmanagedType.LPWStr)]
		public string ManifestPath;

		// Token: 0x02000C0C RID: 3084
		[Flags]
		public enum OpFlags
		{
			// Token: 0x04003669 RID: 13929
			Nothing = 0
		}

		// Token: 0x02000C0D RID: 3085
		public enum Disposition
		{
			// Token: 0x0400366B RID: 13931
			Failed,
			// Token: 0x0400366C RID: 13932
			Installed,
			// Token: 0x0400366D RID: 13933
			Refreshed,
			// Token: 0x0400366E RID: 13934
			AlreadyInstalled
		}
	}
}
