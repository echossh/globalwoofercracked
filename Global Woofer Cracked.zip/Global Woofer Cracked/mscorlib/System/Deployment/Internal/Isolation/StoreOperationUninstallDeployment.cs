﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000679 RID: 1657
	internal struct StoreOperationUninstallDeployment
	{
		// Token: 0x06004EAB RID: 20139 RVA: 0x00117F3B File Offset: 0x0011613B
		[SecuritySafeCritical]
		public StoreOperationUninstallDeployment(IDefinitionAppId appid, StoreApplicationReference AppRef)
		{
			this.Size = (uint)Marshal.SizeOf(typeof(StoreOperationUninstallDeployment));
			this.Flags = StoreOperationUninstallDeployment.OpFlags.Nothing;
			this.Application = appid;
			this.Reference = AppRef.ToIntPtr();
		}

		// Token: 0x06004EAC RID: 20140 RVA: 0x00117F6D File Offset: 0x0011616D
		[SecurityCritical]
		public void Destroy()
		{
			StoreApplicationReference.Destroy(this.Reference);
		}

		// Token: 0x04002185 RID: 8581
		[MarshalAs(UnmanagedType.U4)]
		public uint Size;

		// Token: 0x04002186 RID: 8582
		[MarshalAs(UnmanagedType.U4)]
		public StoreOperationUninstallDeployment.OpFlags Flags;

		// Token: 0x04002187 RID: 8583
		[MarshalAs(UnmanagedType.Interface)]
		public IDefinitionAppId Application;

		// Token: 0x04002188 RID: 8584
		public IntPtr Reference;

		// Token: 0x02000C17 RID: 3095
		[Flags]
		public enum OpFlags
		{
			// Token: 0x0400368B RID: 13963
			Nothing = 0
		}

		// Token: 0x02000C18 RID: 3096
		public enum Disposition
		{
			// Token: 0x0400368D RID: 13965
			Failed,
			// Token: 0x0400368E RID: 13966
			DidNotExist,
			// Token: 0x0400368F RID: 13967
			Uninstalled
		}
	}
}
