﻿using System;
using System.Collections;
using System.Security;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000659 RID: 1625
	internal class StoreAssemblyEnumeration : IEnumerator
	{
		// Token: 0x06004E25 RID: 20005 RVA: 0x00117A44 File Offset: 0x00115C44
		public StoreAssemblyEnumeration(IEnumSTORE_ASSEMBLY pI)
		{
			this._enum = pI;
		}

		// Token: 0x06004E26 RID: 20006 RVA: 0x00117A53 File Offset: 0x00115C53
		private STORE_ASSEMBLY GetCurrent()
		{
			if (!this._fValid)
			{
				throw new InvalidOperationException();
			}
			return this._current;
		}

		// Token: 0x17000C8A RID: 3210
		// (get) Token: 0x06004E27 RID: 20007 RVA: 0x00117A69 File Offset: 0x00115C69
		object IEnumerator.Current
		{
			get
			{
				return this.GetCurrent();
			}
		}

		// Token: 0x17000C8B RID: 3211
		// (get) Token: 0x06004E28 RID: 20008 RVA: 0x00117A76 File Offset: 0x00115C76
		public STORE_ASSEMBLY Current
		{
			get
			{
				return this.GetCurrent();
			}
		}

		// Token: 0x06004E29 RID: 20009 RVA: 0x00117A7E File Offset: 0x00115C7E
		public IEnumerator GetEnumerator()
		{
			return this;
		}

		// Token: 0x06004E2A RID: 20010 RVA: 0x00117A84 File Offset: 0x00115C84
		[SecuritySafeCritical]
		public bool MoveNext()
		{
			STORE_ASSEMBLY[] array = new STORE_ASSEMBLY[1];
			uint num = this._enum.Next(1U, array);
			if (num == 1U)
			{
				this._current = array[0];
			}
			return this._fValid = (num == 1U);
		}

		// Token: 0x06004E2B RID: 20011 RVA: 0x00117AC4 File Offset: 0x00115CC4
		[SecuritySafeCritical]
		public void Reset()
		{
			this._fValid = false;
			this._enum.Reset();
		}

		// Token: 0x04002146 RID: 8518
		private IEnumSTORE_ASSEMBLY _enum;

		// Token: 0x04002147 RID: 8519
		private bool _fValid;

		// Token: 0x04002148 RID: 8520
		private STORE_ASSEMBLY _current;
	}
}
