﻿using System;
using System.Collections;
using System.Security;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000661 RID: 1633
	internal class StoreCategoryInstanceEnumeration : IEnumerator
	{
		// Token: 0x06004E51 RID: 20049 RVA: 0x00117C94 File Offset: 0x00115E94
		public StoreCategoryInstanceEnumeration(IEnumSTORE_CATEGORY_INSTANCE pI)
		{
			this._enum = pI;
		}

		// Token: 0x06004E52 RID: 20050 RVA: 0x00117CA3 File Offset: 0x00115EA3
		public IEnumerator GetEnumerator()
		{
			return this;
		}

		// Token: 0x06004E53 RID: 20051 RVA: 0x00117CA6 File Offset: 0x00115EA6
		private STORE_CATEGORY_INSTANCE GetCurrent()
		{
			if (!this._fValid)
			{
				throw new InvalidOperationException();
			}
			return this._current;
		}

		// Token: 0x17000C92 RID: 3218
		// (get) Token: 0x06004E54 RID: 20052 RVA: 0x00117CBC File Offset: 0x00115EBC
		object IEnumerator.Current
		{
			get
			{
				return this.GetCurrent();
			}
		}

		// Token: 0x17000C93 RID: 3219
		// (get) Token: 0x06004E55 RID: 20053 RVA: 0x00117CC9 File Offset: 0x00115EC9
		public STORE_CATEGORY_INSTANCE Current
		{
			get
			{
				return this.GetCurrent();
			}
		}

		// Token: 0x06004E56 RID: 20054 RVA: 0x00117CD4 File Offset: 0x00115ED4
		[SecuritySafeCritical]
		public bool MoveNext()
		{
			STORE_CATEGORY_INSTANCE[] array = new STORE_CATEGORY_INSTANCE[1];
			uint num = this._enum.Next(1U, array);
			if (num == 1U)
			{
				this._current = array[0];
			}
			return this._fValid = (num == 1U);
		}

		// Token: 0x06004E57 RID: 20055 RVA: 0x00117D14 File Offset: 0x00115F14
		[SecuritySafeCritical]
		public void Reset()
		{
			this._fValid = false;
			this._enum.Reset();
		}

		// Token: 0x04002152 RID: 8530
		private IEnumSTORE_CATEGORY_INSTANCE _enum;

		// Token: 0x04002153 RID: 8531
		private bool _fValid;

		// Token: 0x04002154 RID: 8532
		private STORE_CATEGORY_INSTANCE _current;
	}
}
