﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006C0 RID: 1728
	internal enum CLRSurrogateEntryFieldId
	{
		// Token: 0x0400229C RID: 8860
		CLRSurrogate_RuntimeVersion,
		// Token: 0x0400229D RID: 8861
		CLRSurrogate_ClassName
	}
}
