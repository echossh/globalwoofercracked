﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006B4 RID: 1716
	internal enum SubcategoryMembershipEntryFieldId
	{
		// Token: 0x0400227F RID: 8831
		SubcategoryMembership_CategoryMembershipData
	}
}
