﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006A7 RID: 1703
	[StructLayout(LayoutKind.Sequential)]
	internal class HashElementEntry : IDisposable
	{
		// Token: 0x06004F45 RID: 20293 RVA: 0x00119128 File Offset: 0x00117328
		~HashElementEntry()
		{
			this.Dispose(false);
		}

		// Token: 0x06004F46 RID: 20294 RVA: 0x00119158 File Offset: 0x00117358
		void IDisposable.Dispose()
		{
			this.Dispose(true);
		}

		// Token: 0x06004F47 RID: 20295 RVA: 0x00119164 File Offset: 0x00117364
		[SecuritySafeCritical]
		public void Dispose(bool fDisposing)
		{
			if (this.TransformMetadata != IntPtr.Zero)
			{
				Marshal.FreeCoTaskMem(this.TransformMetadata);
				this.TransformMetadata = IntPtr.Zero;
			}
			if (this.DigestValue != IntPtr.Zero)
			{
				Marshal.FreeCoTaskMem(this.DigestValue);
				this.DigestValue = IntPtr.Zero;
			}
			if (fDisposing)
			{
				GC.SuppressFinalize(this);
			}
		}

		// Token: 0x0400223E RID: 8766
		public uint index;

		// Token: 0x0400223F RID: 8767
		public byte Transform;

		// Token: 0x04002240 RID: 8768
		[MarshalAs(UnmanagedType.SysInt)]
		public IntPtr TransformMetadata;

		// Token: 0x04002241 RID: 8769
		public uint TransformMetadataSize;

		// Token: 0x04002242 RID: 8770
		public byte DigestMethod;

		// Token: 0x04002243 RID: 8771
		[MarshalAs(UnmanagedType.SysInt)]
		public IntPtr DigestValue;

		// Token: 0x04002244 RID: 8772
		public uint DigestValueSize;

		// Token: 0x04002245 RID: 8773
		[MarshalAs(UnmanagedType.LPWStr)]
		public string Xml;
	}
}
