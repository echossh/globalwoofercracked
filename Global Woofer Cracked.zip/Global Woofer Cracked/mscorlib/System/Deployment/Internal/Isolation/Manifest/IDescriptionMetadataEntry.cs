﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006D9 RID: 1753
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("CB73147E-5FC2-4c31-B4E6-58D13DBE1A08")]
	[ComImport]
	internal interface IDescriptionMetadataEntry
	{
		// Token: 0x17000D11 RID: 3345
		// (get) Token: 0x06004FB7 RID: 20407
		DescriptionMetadataEntry AllData { [SecurityCritical] get; }

		// Token: 0x17000D12 RID: 3346
		// (get) Token: 0x06004FB8 RID: 20408
		string Publisher { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000D13 RID: 3347
		// (get) Token: 0x06004FB9 RID: 20409
		string Product { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000D14 RID: 3348
		// (get) Token: 0x06004FBA RID: 20410
		string SupportUrl { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000D15 RID: 3349
		// (get) Token: 0x06004FBB RID: 20411
		string IconFile { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000D16 RID: 3350
		// (get) Token: 0x06004FBC RID: 20412
		string ErrorReportUrl { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000D17 RID: 3351
		// (get) Token: 0x06004FBD RID: 20413
		string SuiteName { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }
	}
}
