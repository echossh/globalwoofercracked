﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006C4 RID: 1732
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("C31FF59E-CD25-47b8-9EF3-CF4433EB97CC")]
	[ComImport]
	internal interface IAssemblyReferenceDependentAssemblyEntry
	{
		// Token: 0x17000CEF RID: 3311
		// (get) Token: 0x06004F8E RID: 20366
		AssemblyReferenceDependentAssemblyEntry AllData { [SecurityCritical] get; }

		// Token: 0x17000CF0 RID: 3312
		// (get) Token: 0x06004F8F RID: 20367
		string Group { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000CF1 RID: 3313
		// (get) Token: 0x06004F90 RID: 20368
		string Codebase { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000CF2 RID: 3314
		// (get) Token: 0x06004F91 RID: 20369
		ulong Size { [SecurityCritical] get; }

		// Token: 0x17000CF3 RID: 3315
		// (get) Token: 0x06004F92 RID: 20370
		object HashValue { [SecurityCritical] [return: MarshalAs(UnmanagedType.Interface)] get; }

		// Token: 0x17000CF4 RID: 3316
		// (get) Token: 0x06004F93 RID: 20371
		uint HashAlgorithm { [SecurityCritical] get; }

		// Token: 0x17000CF5 RID: 3317
		// (get) Token: 0x06004F94 RID: 20372
		uint Flags { [SecurityCritical] get; }

		// Token: 0x17000CF6 RID: 3318
		// (get) Token: 0x06004F95 RID: 20373
		string ResourceFallbackCulture { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000CF7 RID: 3319
		// (get) Token: 0x06004F96 RID: 20374
		string Description { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000CF8 RID: 3320
		// (get) Token: 0x06004F97 RID: 20375
		string SupportUrl { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000CF9 RID: 3321
		// (get) Token: 0x06004F98 RID: 20376
		ISection HashElements { [SecurityCritical] get; }
	}
}
