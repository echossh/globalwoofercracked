﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006A8 RID: 1704
	internal enum HashElementEntryFieldId
	{
		// Token: 0x04002247 RID: 8775
		HashElement_Transform,
		// Token: 0x04002248 RID: 8776
		HashElement_TransformMetadata,
		// Token: 0x04002249 RID: 8777
		HashElement_TransformMetadataSize,
		// Token: 0x0400224A RID: 8778
		HashElement_DigestMethod,
		// Token: 0x0400224B RID: 8779
		HashElement_DigestValue,
		// Token: 0x0400224C RID: 8780
		HashElement_DigestValueSize,
		// Token: 0x0400224D RID: 8781
		HashElement_Xml
	}
}
