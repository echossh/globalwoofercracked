﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006CC RID: 1740
	internal enum ResourceTableMappingEntryFieldId
	{
		// Token: 0x040022C4 RID: 8900
		ResourceTableMapping_FinalStringMapped
	}
}
