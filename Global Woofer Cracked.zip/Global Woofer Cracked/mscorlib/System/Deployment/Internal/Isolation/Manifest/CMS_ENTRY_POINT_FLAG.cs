﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x02000691 RID: 1681
	internal enum CMS_ENTRY_POINT_FLAG
	{
		// Token: 0x040021FC RID: 8700
		CMS_ENTRY_POINT_FLAG_HOST_IN_BROWSER = 1,
		// Token: 0x040021FD RID: 8701
		CMS_ENTRY_POINT_FLAG_CUSTOMHOSTSPECIFIED,
		// Token: 0x040021FE RID: 8702
		CMS_ENTRY_POINT_FLAG_CUSTOMUX = 4
	}
}
