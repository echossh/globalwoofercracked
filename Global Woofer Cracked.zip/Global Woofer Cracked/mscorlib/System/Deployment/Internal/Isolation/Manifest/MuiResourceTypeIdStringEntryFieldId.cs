﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x0200069F RID: 1695
	internal enum MuiResourceTypeIdStringEntryFieldId
	{
		// Token: 0x04002228 RID: 8744
		MuiResourceTypeIdString_StringIds,
		// Token: 0x04002229 RID: 8745
		MuiResourceTypeIdString_StringIdsSize,
		// Token: 0x0400222A RID: 8746
		MuiResourceTypeIdString_IntegerIds,
		// Token: 0x0400222B RID: 8747
		MuiResourceTypeIdString_IntegerIdsSize
	}
}
