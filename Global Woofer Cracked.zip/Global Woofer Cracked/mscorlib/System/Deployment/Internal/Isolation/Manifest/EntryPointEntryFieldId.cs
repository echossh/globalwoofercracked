﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006CF RID: 1743
	internal enum EntryPointEntryFieldId
	{
		// Token: 0x040022CB RID: 8907
		EntryPoint_CommandLine_File,
		// Token: 0x040022CC RID: 8908
		EntryPoint_CommandLine_Parameters,
		// Token: 0x040022CD RID: 8909
		EntryPoint_Identity,
		// Token: 0x040022CE RID: 8910
		EntryPoint_Flags
	}
}
