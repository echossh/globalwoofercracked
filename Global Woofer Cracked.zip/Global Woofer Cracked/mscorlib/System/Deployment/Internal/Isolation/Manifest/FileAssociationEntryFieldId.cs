﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006AE RID: 1710
	internal enum FileAssociationEntryFieldId
	{
		// Token: 0x04002272 RID: 8818
		FileAssociation_Description,
		// Token: 0x04002273 RID: 8819
		FileAssociation_ProgID,
		// Token: 0x04002274 RID: 8820
		FileAssociation_DefaultIcon,
		// Token: 0x04002275 RID: 8821
		FileAssociation_Parameter
	}
}
