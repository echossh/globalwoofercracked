﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x02000696 RID: 1686
	internal enum CMS_TIME_UNIT_TYPE
	{
		// Token: 0x04002211 RID: 8721
		CMS_TIME_UNIT_TYPE_HOURS = 1,
		// Token: 0x04002212 RID: 8722
		CMS_TIME_UNIT_TYPE_DAYS,
		// Token: 0x04002213 RID: 8723
		CMS_TIME_UNIT_TYPE_WEEKS,
		// Token: 0x04002214 RID: 8724
		CMS_TIME_UNIT_TYPE_MONTHS
	}
}
