﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x02000692 RID: 1682
	internal enum CMS_COM_SERVER_FLAG
	{
		// Token: 0x04002200 RID: 8704
		CMS_COM_SERVER_FLAG_IS_CLR_CLASS = 1
	}
}
