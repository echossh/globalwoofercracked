﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006B7 RID: 1719
	internal enum CategoryMembershipEntryFieldId
	{
		// Token: 0x04002283 RID: 8835
		CategoryMembership_SubcategoryMembership
	}
}
