﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006D8 RID: 1752
	internal enum DescriptionMetadataEntryFieldId
	{
		// Token: 0x040022DE RID: 8926
		DescriptionMetadata_Publisher,
		// Token: 0x040022DF RID: 8927
		DescriptionMetadata_Product,
		// Token: 0x040022E0 RID: 8928
		DescriptionMetadata_SupportUrl,
		// Token: 0x040022E1 RID: 8929
		DescriptionMetadata_IconFile,
		// Token: 0x040022E2 RID: 8930
		DescriptionMetadata_ErrorReportUrl,
		// Token: 0x040022E3 RID: 8931
		DescriptionMetadata_SuiteName
	}
}
