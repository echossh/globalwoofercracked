﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006BB RID: 1723
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("3903B11B-FBE8-477c-825F-DB828B5FD174")]
	[ComImport]
	internal interface ICOMServerEntry
	{
		// Token: 0x17000CDF RID: 3295
		// (get) Token: 0x06004F78 RID: 20344
		COMServerEntry AllData { [SecurityCritical] get; }

		// Token: 0x17000CE0 RID: 3296
		// (get) Token: 0x06004F79 RID: 20345
		Guid Clsid { [SecurityCritical] get; }

		// Token: 0x17000CE1 RID: 3297
		// (get) Token: 0x06004F7A RID: 20346
		uint Flags { [SecurityCritical] get; }

		// Token: 0x17000CE2 RID: 3298
		// (get) Token: 0x06004F7B RID: 20347
		Guid ConfiguredGuid { [SecurityCritical] get; }

		// Token: 0x17000CE3 RID: 3299
		// (get) Token: 0x06004F7C RID: 20348
		Guid ImplementedClsid { [SecurityCritical] get; }

		// Token: 0x17000CE4 RID: 3300
		// (get) Token: 0x06004F7D RID: 20349
		Guid TypeLibrary { [SecurityCritical] get; }

		// Token: 0x17000CE5 RID: 3301
		// (get) Token: 0x06004F7E RID: 20350
		uint ThreadingModel { [SecurityCritical] get; }

		// Token: 0x17000CE6 RID: 3302
		// (get) Token: 0x06004F7F RID: 20351
		string RuntimeVersion { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000CE7 RID: 3303
		// (get) Token: 0x06004F80 RID: 20352
		string HostFile { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }
	}
}
