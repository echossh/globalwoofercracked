﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006C6 RID: 1734
	internal enum AssemblyReferenceEntryFieldId
	{
		// Token: 0x040022B9 RID: 8889
		AssemblyReference_Flags,
		// Token: 0x040022BA RID: 8890
		AssemblyReference_DependentAssembly
	}
}
