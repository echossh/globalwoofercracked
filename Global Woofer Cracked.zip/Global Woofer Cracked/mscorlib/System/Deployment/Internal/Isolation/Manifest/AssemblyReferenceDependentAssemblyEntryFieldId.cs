﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006C3 RID: 1731
	internal enum AssemblyReferenceDependentAssemblyEntryFieldId
	{
		// Token: 0x040022AA RID: 8874
		AssemblyReferenceDependentAssembly_Group,
		// Token: 0x040022AB RID: 8875
		AssemblyReferenceDependentAssembly_Codebase,
		// Token: 0x040022AC RID: 8876
		AssemblyReferenceDependentAssembly_Size,
		// Token: 0x040022AD RID: 8877
		AssemblyReferenceDependentAssembly_HashValue,
		// Token: 0x040022AE RID: 8878
		AssemblyReferenceDependentAssembly_HashValueSize,
		// Token: 0x040022AF RID: 8879
		AssemblyReferenceDependentAssembly_HashAlgorithm,
		// Token: 0x040022B0 RID: 8880
		AssemblyReferenceDependentAssembly_Flags,
		// Token: 0x040022B1 RID: 8881
		AssemblyReferenceDependentAssembly_ResourceFallbackCulture,
		// Token: 0x040022B2 RID: 8882
		AssemblyReferenceDependentAssembly_Description,
		// Token: 0x040022B3 RID: 8883
		AssemblyReferenceDependentAssembly_SupportUrl,
		// Token: 0x040022B4 RID: 8884
		AssemblyReferenceDependentAssembly_HashElements
	}
}
