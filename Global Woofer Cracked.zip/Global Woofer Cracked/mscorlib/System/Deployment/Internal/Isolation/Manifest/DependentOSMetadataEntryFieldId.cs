﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006DE RID: 1758
	internal enum DependentOSMetadataEntryFieldId
	{
		// Token: 0x040022F7 RID: 8951
		DependentOSMetadata_SupportUrl,
		// Token: 0x040022F8 RID: 8952
		DependentOSMetadata_Description,
		// Token: 0x040022F9 RID: 8953
		DependentOSMetadata_MajorVersion,
		// Token: 0x040022FA RID: 8954
		DependentOSMetadata_MinorVersion,
		// Token: 0x040022FB RID: 8955
		DependentOSMetadata_BuildNumber,
		// Token: 0x040022FC RID: 8956
		DependentOSMetadata_ServicePackMajor,
		// Token: 0x040022FD RID: 8957
		DependentOSMetadata_ServicePackMinor
	}
}
