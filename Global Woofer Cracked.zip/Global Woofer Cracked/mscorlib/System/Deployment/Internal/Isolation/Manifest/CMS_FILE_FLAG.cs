﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x02000690 RID: 1680
	internal enum CMS_FILE_FLAG
	{
		// Token: 0x040021FA RID: 8698
		CMS_FILE_FLAG_OPTIONAL = 1
	}
}
