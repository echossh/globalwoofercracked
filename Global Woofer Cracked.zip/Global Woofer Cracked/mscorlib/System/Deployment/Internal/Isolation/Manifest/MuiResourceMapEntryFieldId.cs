﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006A5 RID: 1701
	internal enum MuiResourceMapEntryFieldId
	{
		// Token: 0x0400223A RID: 8762
		MuiResourceMap_ResourceTypeIdInt,
		// Token: 0x0400223B RID: 8763
		MuiResourceMap_ResourceTypeIdIntSize,
		// Token: 0x0400223C RID: 8764
		MuiResourceMap_ResourceTypeIdString,
		// Token: 0x0400223D RID: 8765
		MuiResourceMap_ResourceTypeIdStringSize
	}
}
