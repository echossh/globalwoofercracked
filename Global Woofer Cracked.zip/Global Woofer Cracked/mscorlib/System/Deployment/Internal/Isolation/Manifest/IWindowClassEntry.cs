﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006CA RID: 1738
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("8AD3FC86-AFD3-477a-8FD5-146C291195BA")]
	[ComImport]
	internal interface IWindowClassEntry
	{
		// Token: 0x17000CFE RID: 3326
		// (get) Token: 0x06004F9F RID: 20383
		WindowClassEntry AllData { [SecurityCritical] get; }

		// Token: 0x17000CFF RID: 3327
		// (get) Token: 0x06004FA0 RID: 20384
		string ClassName { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000D00 RID: 3328
		// (get) Token: 0x06004FA1 RID: 20385
		string HostDll { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000D01 RID: 3329
		// (get) Token: 0x06004FA2 RID: 20386
		bool fVersioned { [SecurityCritical] get; }
	}
}
