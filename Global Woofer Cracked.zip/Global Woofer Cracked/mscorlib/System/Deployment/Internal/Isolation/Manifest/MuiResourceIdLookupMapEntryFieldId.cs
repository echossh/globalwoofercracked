﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x0200069C RID: 1692
	internal enum MuiResourceIdLookupMapEntryFieldId
	{
		// Token: 0x04002222 RID: 8738
		MuiResourceIdLookupMap_Count
	}
}
