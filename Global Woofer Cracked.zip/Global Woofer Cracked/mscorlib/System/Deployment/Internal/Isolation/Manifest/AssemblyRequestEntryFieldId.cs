﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006D5 RID: 1749
	internal enum AssemblyRequestEntryFieldId
	{
		// Token: 0x040022D6 RID: 8918
		AssemblyRequest_permissionSetID
	}
}
