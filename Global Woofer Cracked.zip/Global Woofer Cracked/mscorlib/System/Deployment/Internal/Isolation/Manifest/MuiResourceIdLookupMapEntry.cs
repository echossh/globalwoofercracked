﻿using System;
using System.Runtime.InteropServices;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x0200069B RID: 1691
	[StructLayout(LayoutKind.Sequential)]
	internal class MuiResourceIdLookupMapEntry
	{
		// Token: 0x04002220 RID: 8736
		public uint Count;
	}
}
