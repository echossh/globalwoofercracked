﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006BD RID: 1725
	internal enum ProgIdRedirectionEntryFieldId
	{
		// Token: 0x04002297 RID: 8855
		ProgIdRedirection_RedirectedGuid
	}
}
