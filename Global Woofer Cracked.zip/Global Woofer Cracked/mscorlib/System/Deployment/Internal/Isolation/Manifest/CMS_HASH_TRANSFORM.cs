﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x02000698 RID: 1688
	internal enum CMS_HASH_TRANSFORM
	{
		// Token: 0x04002219 RID: 8729
		CMS_HASH_TRANSFORM_IDENTITY = 1,
		// Token: 0x0400221A RID: 8730
		CMS_HASH_TRANSFORM_MANIFESTINVARIANT
	}
}
