﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006C9 RID: 1737
	internal enum WindowClassEntryFieldId
	{
		// Token: 0x040022BF RID: 8895
		WindowClass_HostDll,
		// Token: 0x040022C0 RID: 8896
		WindowClass_fVersioned
	}
}
