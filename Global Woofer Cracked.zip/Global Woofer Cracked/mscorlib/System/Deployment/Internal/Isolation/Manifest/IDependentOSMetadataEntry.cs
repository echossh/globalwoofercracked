﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006DF RID: 1759
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("CF168CF4-4E8F-4d92-9D2A-60E5CA21CF85")]
	[ComImport]
	internal interface IDependentOSMetadataEntry
	{
		// Token: 0x17000D1E RID: 3358
		// (get) Token: 0x06004FC6 RID: 20422
		DependentOSMetadataEntry AllData { [SecurityCritical] get; }

		// Token: 0x17000D1F RID: 3359
		// (get) Token: 0x06004FC7 RID: 20423
		string SupportUrl { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000D20 RID: 3360
		// (get) Token: 0x06004FC8 RID: 20424
		string Description { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000D21 RID: 3361
		// (get) Token: 0x06004FC9 RID: 20425
		ushort MajorVersion { [SecurityCritical] get; }

		// Token: 0x17000D22 RID: 3362
		// (get) Token: 0x06004FCA RID: 20426
		ushort MinorVersion { [SecurityCritical] get; }

		// Token: 0x17000D23 RID: 3363
		// (get) Token: 0x06004FCB RID: 20427
		ushort BuildNumber { [SecurityCritical] get; }

		// Token: 0x17000D24 RID: 3364
		// (get) Token: 0x06004FCC RID: 20428
		byte ServicePackMajor { [SecurityCritical] get; }

		// Token: 0x17000D25 RID: 3365
		// (get) Token: 0x06004FCD RID: 20429
		byte ServicePackMinor { [SecurityCritical] get; }
	}
}
