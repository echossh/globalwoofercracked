﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006A2 RID: 1698
	internal enum MuiResourceTypeIdIntEntryFieldId
	{
		// Token: 0x04002231 RID: 8753
		MuiResourceTypeIdInt_StringIds,
		// Token: 0x04002232 RID: 8754
		MuiResourceTypeIdInt_StringIdsSize,
		// Token: 0x04002233 RID: 8755
		MuiResourceTypeIdInt_IntegerIds,
		// Token: 0x04002234 RID: 8756
		MuiResourceTypeIdInt_IntegerIdsSize
	}
}
