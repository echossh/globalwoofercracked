﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006AC RID: 1708
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("A2A55FAD-349B-469b-BF12-ADC33D14A937")]
	[ComImport]
	internal interface IFileEntry
	{
		// Token: 0x17000CC0 RID: 3264
		// (get) Token: 0x06004F54 RID: 20308
		FileEntry AllData { [SecurityCritical] get; }

		// Token: 0x17000CC1 RID: 3265
		// (get) Token: 0x06004F55 RID: 20309
		string Name { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000CC2 RID: 3266
		// (get) Token: 0x06004F56 RID: 20310
		uint HashAlgorithm { [SecurityCritical] get; }

		// Token: 0x17000CC3 RID: 3267
		// (get) Token: 0x06004F57 RID: 20311
		string LoadFrom { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000CC4 RID: 3268
		// (get) Token: 0x06004F58 RID: 20312
		string SourcePath { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000CC5 RID: 3269
		// (get) Token: 0x06004F59 RID: 20313
		string ImportPath { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000CC6 RID: 3270
		// (get) Token: 0x06004F5A RID: 20314
		string SourceName { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000CC7 RID: 3271
		// (get) Token: 0x06004F5B RID: 20315
		string Location { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000CC8 RID: 3272
		// (get) Token: 0x06004F5C RID: 20316
		object HashValue { [SecurityCritical] [return: MarshalAs(UnmanagedType.Interface)] get; }

		// Token: 0x17000CC9 RID: 3273
		// (get) Token: 0x06004F5D RID: 20317
		ulong Size { [SecurityCritical] get; }

		// Token: 0x17000CCA RID: 3274
		// (get) Token: 0x06004F5E RID: 20318
		string Group { [SecurityCritical] [return: MarshalAs(UnmanagedType.LPWStr)] get; }

		// Token: 0x17000CCB RID: 3275
		// (get) Token: 0x06004F5F RID: 20319
		uint Flags { [SecurityCritical] get; }

		// Token: 0x17000CCC RID: 3276
		// (get) Token: 0x06004F60 RID: 20320
		IMuiResourceMapEntry MuiMapping { [SecurityCritical] get; }

		// Token: 0x17000CCD RID: 3277
		// (get) Token: 0x06004F61 RID: 20321
		uint WritableType { [SecurityCritical] get; }

		// Token: 0x17000CCE RID: 3278
		// (get) Token: 0x06004F62 RID: 20322
		ISection HashElements { [SecurityCritical] get; }
	}
}
