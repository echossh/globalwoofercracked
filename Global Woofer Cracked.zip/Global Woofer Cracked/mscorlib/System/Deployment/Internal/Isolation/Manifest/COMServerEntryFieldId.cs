﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006BA RID: 1722
	internal enum COMServerEntryFieldId
	{
		// Token: 0x0400228D RID: 8845
		COMServer_Flags,
		// Token: 0x0400228E RID: 8846
		COMServer_ConfiguredGuid,
		// Token: 0x0400228F RID: 8847
		COMServer_ImplementedClsid,
		// Token: 0x04002290 RID: 8848
		COMServer_TypeLibrary,
		// Token: 0x04002291 RID: 8849
		COMServer_ThreadingModel,
		// Token: 0x04002292 RID: 8850
		COMServer_RuntimeVersion,
		// Token: 0x04002293 RID: 8851
		COMServer_HostFile
	}
}
