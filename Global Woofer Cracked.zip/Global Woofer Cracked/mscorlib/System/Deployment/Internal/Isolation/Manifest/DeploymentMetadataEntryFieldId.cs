﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006DB RID: 1755
	internal enum DeploymentMetadataEntryFieldId
	{
		// Token: 0x040022EA RID: 8938
		DeploymentMetadata_DeploymentProviderCodebase,
		// Token: 0x040022EB RID: 8939
		DeploymentMetadata_MinimumRequiredVersion,
		// Token: 0x040022EC RID: 8940
		DeploymentMetadata_MaximumAge,
		// Token: 0x040022ED RID: 8941
		DeploymentMetadata_MaximumAge_Unit,
		// Token: 0x040022EE RID: 8942
		DeploymentMetadata_DeploymentFlags
	}
}
