﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006B1 RID: 1713
	internal enum CategoryMembershipDataEntryFieldId
	{
		// Token: 0x0400227A RID: 8826
		CategoryMembershipData_Xml,
		// Token: 0x0400227B RID: 8827
		CategoryMembershipData_Description
	}
}
