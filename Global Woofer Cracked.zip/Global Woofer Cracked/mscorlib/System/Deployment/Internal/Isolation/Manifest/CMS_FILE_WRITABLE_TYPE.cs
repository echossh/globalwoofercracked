﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x02000697 RID: 1687
	internal enum CMS_FILE_WRITABLE_TYPE
	{
		// Token: 0x04002216 RID: 8726
		CMS_FILE_WRITABLE_TYPE_NOT_WRITABLE = 1,
		// Token: 0x04002217 RID: 8727
		CMS_FILE_WRITABLE_TYPE_APPLICATION_DATA
	}
}
