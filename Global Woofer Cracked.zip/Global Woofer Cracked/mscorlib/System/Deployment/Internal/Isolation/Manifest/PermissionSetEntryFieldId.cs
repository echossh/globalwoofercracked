﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006D2 RID: 1746
	internal enum PermissionSetEntryFieldId
	{
		// Token: 0x040022D2 RID: 8914
		PermissionSet_XmlSegment
	}
}
