﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x020006E1 RID: 1761
	internal enum CompatibleFrameworksMetadataEntryFieldId
	{
		// Token: 0x04002300 RID: 8960
		CompatibleFrameworksMetadata_SupportUrl
	}
}
