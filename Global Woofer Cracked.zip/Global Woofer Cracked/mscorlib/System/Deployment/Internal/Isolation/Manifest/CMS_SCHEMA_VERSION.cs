﻿using System;

namespace System.Deployment.Internal.Isolation.Manifest
{
	// Token: 0x02000694 RID: 1684
	internal enum CMS_SCHEMA_VERSION
	{
		// Token: 0x04002207 RID: 8711
		CMS_SCHEMA_VERSION_V1 = 1
	}
}
