﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000677 RID: 1655
	internal struct StoreOperationUnpinDeployment
	{
		// Token: 0x06004EA6 RID: 20134 RVA: 0x00117E94 File Offset: 0x00116094
		[SecuritySafeCritical]
		public StoreOperationUnpinDeployment(IDefinitionAppId app, StoreApplicationReference reference)
		{
			this.Size = (uint)Marshal.SizeOf(typeof(StoreOperationUnpinDeployment));
			this.Flags = StoreOperationUnpinDeployment.OpFlags.Nothing;
			this.Application = app;
			this.Reference = reference.ToIntPtr();
		}

		// Token: 0x06004EA7 RID: 20135 RVA: 0x00117EC6 File Offset: 0x001160C6
		[SecurityCritical]
		public void Destroy()
		{
			StoreApplicationReference.Destroy(this.Reference);
		}

		// Token: 0x0400217D RID: 8573
		[MarshalAs(UnmanagedType.U4)]
		public uint Size;

		// Token: 0x0400217E RID: 8574
		[MarshalAs(UnmanagedType.U4)]
		public StoreOperationUnpinDeployment.OpFlags Flags;

		// Token: 0x0400217F RID: 8575
		[MarshalAs(UnmanagedType.Interface)]
		public IDefinitionAppId Application;

		// Token: 0x04002180 RID: 8576
		public IntPtr Reference;

		// Token: 0x02000C13 RID: 3091
		[Flags]
		public enum OpFlags
		{
			// Token: 0x0400367F RID: 13951
			Nothing = 0
		}

		// Token: 0x02000C14 RID: 3092
		public enum Disposition
		{
			// Token: 0x04003681 RID: 13953
			Failed,
			// Token: 0x04003682 RID: 13954
			Unpinned
		}
	}
}
