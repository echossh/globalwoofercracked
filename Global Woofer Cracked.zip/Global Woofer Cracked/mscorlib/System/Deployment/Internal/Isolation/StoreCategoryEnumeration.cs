﻿using System;
using System.Collections;
using System.Security;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x0200065D RID: 1629
	internal class StoreCategoryEnumeration : IEnumerator
	{
		// Token: 0x06004E3B RID: 20027 RVA: 0x00117B6C File Offset: 0x00115D6C
		public StoreCategoryEnumeration(IEnumSTORE_CATEGORY pI)
		{
			this._enum = pI;
		}

		// Token: 0x06004E3C RID: 20028 RVA: 0x00117B7B File Offset: 0x00115D7B
		public IEnumerator GetEnumerator()
		{
			return this;
		}

		// Token: 0x06004E3D RID: 20029 RVA: 0x00117B7E File Offset: 0x00115D7E
		private STORE_CATEGORY GetCurrent()
		{
			if (!this._fValid)
			{
				throw new InvalidOperationException();
			}
			return this._current;
		}

		// Token: 0x17000C8E RID: 3214
		// (get) Token: 0x06004E3E RID: 20030 RVA: 0x00117B94 File Offset: 0x00115D94
		object IEnumerator.Current
		{
			get
			{
				return this.GetCurrent();
			}
		}

		// Token: 0x17000C8F RID: 3215
		// (get) Token: 0x06004E3F RID: 20031 RVA: 0x00117BA1 File Offset: 0x00115DA1
		public STORE_CATEGORY Current
		{
			get
			{
				return this.GetCurrent();
			}
		}

		// Token: 0x06004E40 RID: 20032 RVA: 0x00117BAC File Offset: 0x00115DAC
		[SecuritySafeCritical]
		public bool MoveNext()
		{
			STORE_CATEGORY[] array = new STORE_CATEGORY[1];
			uint num = this._enum.Next(1U, array);
			if (num == 1U)
			{
				this._current = array[0];
			}
			return this._fValid = (num == 1U);
		}

		// Token: 0x06004E41 RID: 20033 RVA: 0x00117BEC File Offset: 0x00115DEC
		[SecuritySafeCritical]
		public void Reset()
		{
			this._fValid = false;
			this._enum.Reset();
		}

		// Token: 0x0400214C RID: 8524
		private IEnumSTORE_CATEGORY _enum;

		// Token: 0x0400214D RID: 8525
		private bool _fValid;

		// Token: 0x0400214E RID: 8526
		private STORE_CATEGORY _current;
	}
}
