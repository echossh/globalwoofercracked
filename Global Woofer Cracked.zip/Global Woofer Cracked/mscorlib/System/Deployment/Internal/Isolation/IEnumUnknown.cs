﻿using System;
using System.Runtime.InteropServices;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000645 RID: 1605
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("00000100-0000-0000-C000-000000000046")]
	[ComImport]
	internal interface IEnumUnknown
	{
		// Token: 0x06004DFD RID: 19965
		[PreserveSig]
		int Next(uint celt, [MarshalAs(UnmanagedType.LPArray, ArraySubType = UnmanagedType.IUnknown)] [Out] object[] rgelt, ref uint celtFetched);

		// Token: 0x06004DFE RID: 19966
		[PreserveSig]
		int Skip(uint celt);

		// Token: 0x06004DFF RID: 19967
		[PreserveSig]
		int Reset();

		// Token: 0x06004E00 RID: 19968
		[PreserveSig]
		int Clone(out IEnumUnknown enumUnknown);
	}
}
