﻿using System;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x0200068A RID: 1674
	internal enum StateManager_RunningState
	{
		// Token: 0x040021C9 RID: 8649
		Undefined,
		// Token: 0x040021CA RID: 8650
		Starting,
		// Token: 0x040021CB RID: 8651
		Running
	}
}
