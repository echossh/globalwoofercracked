﻿using System;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x0200066A RID: 1642
	internal enum IIDENTITYAUTHORITY_REFERENCE_IDENTITY_TO_TEXT_FLAGS
	{
		// Token: 0x04002158 RID: 8536
		IIDENTITYAUTHORITY_REFERENCE_IDENTITY_TO_TEXT_FLAG_CANONICAL = 1
	}
}
