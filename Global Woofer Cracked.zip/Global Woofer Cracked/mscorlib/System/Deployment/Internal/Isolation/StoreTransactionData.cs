﻿using System;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000680 RID: 1664
	internal struct StoreTransactionData
	{
		// Token: 0x040021AB RID: 8619
		public IntPtr DataPtr;
	}
}
