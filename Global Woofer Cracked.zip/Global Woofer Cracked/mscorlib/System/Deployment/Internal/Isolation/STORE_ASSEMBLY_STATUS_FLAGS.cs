﻿using System;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000649 RID: 1609
	[Flags]
	internal enum STORE_ASSEMBLY_STATUS_FLAGS
	{
		// Token: 0x0400212A RID: 8490
		STORE_ASSEMBLY_STATUS_MANIFEST_ONLY = 1,
		// Token: 0x0400212B RID: 8491
		STORE_ASSEMBLY_STATUS_PAYLOAD_RESIDENT = 2,
		// Token: 0x0400212C RID: 8492
		STORE_ASSEMBLY_STATUS_PARTIAL_INSTALL = 4
	}
}
