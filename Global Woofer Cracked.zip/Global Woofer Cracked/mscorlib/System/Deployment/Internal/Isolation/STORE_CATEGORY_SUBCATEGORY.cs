﻿using System;
using System.Runtime.InteropServices;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x0200064E RID: 1614
	internal struct STORE_CATEGORY_SUBCATEGORY
	{
		// Token: 0x04002139 RID: 8505
		[MarshalAs(UnmanagedType.LPWStr)]
		public string Subcategory;
	}
}
