﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000676 RID: 1654
	internal struct StoreOperationPinDeployment
	{
		// Token: 0x06004EA3 RID: 20131 RVA: 0x00117E35 File Offset: 0x00116035
		[SecuritySafeCritical]
		public StoreOperationPinDeployment(IDefinitionAppId AppId, StoreApplicationReference Ref)
		{
			this.Size = (uint)Marshal.SizeOf(typeof(StoreOperationPinDeployment));
			this.Flags = StoreOperationPinDeployment.OpFlags.NeverExpires;
			this.Application = AppId;
			this.Reference = Ref.ToIntPtr();
			this.ExpirationTime = 0L;
		}

		// Token: 0x06004EA4 RID: 20132 RVA: 0x00117E6F File Offset: 0x0011606F
		public StoreOperationPinDeployment(IDefinitionAppId AppId, DateTime Expiry, StoreApplicationReference Ref)
		{
			this = new StoreOperationPinDeployment(AppId, Ref);
			this.Flags |= StoreOperationPinDeployment.OpFlags.NeverExpires;
		}

		// Token: 0x06004EA5 RID: 20133 RVA: 0x00117E87 File Offset: 0x00116087
		[SecurityCritical]
		public void Destroy()
		{
			StoreApplicationReference.Destroy(this.Reference);
		}

		// Token: 0x04002178 RID: 8568
		[MarshalAs(UnmanagedType.U4)]
		public uint Size;

		// Token: 0x04002179 RID: 8569
		[MarshalAs(UnmanagedType.U4)]
		public StoreOperationPinDeployment.OpFlags Flags;

		// Token: 0x0400217A RID: 8570
		[MarshalAs(UnmanagedType.Interface)]
		public IDefinitionAppId Application;

		// Token: 0x0400217B RID: 8571
		[MarshalAs(UnmanagedType.I8)]
		public long ExpirationTime;

		// Token: 0x0400217C RID: 8572
		public IntPtr Reference;

		// Token: 0x02000C11 RID: 3089
		[Flags]
		public enum OpFlags
		{
			// Token: 0x04003679 RID: 13945
			Nothing = 0,
			// Token: 0x0400367A RID: 13946
			NeverExpires = 1
		}

		// Token: 0x02000C12 RID: 3090
		public enum Disposition
		{
			// Token: 0x0400367C RID: 13948
			Failed,
			// Token: 0x0400367D RID: 13949
			Pinned
		}
	}
}
