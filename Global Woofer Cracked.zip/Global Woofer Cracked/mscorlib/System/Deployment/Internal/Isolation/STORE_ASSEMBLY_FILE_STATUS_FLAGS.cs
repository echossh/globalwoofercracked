﻿using System;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x0200064B RID: 1611
	[Flags]
	internal enum STORE_ASSEMBLY_FILE_STATUS_FLAGS
	{
		// Token: 0x04002133 RID: 8499
		STORE_ASSEMBLY_FILE_STATUS_FLAG_PRESENT = 1
	}
}
