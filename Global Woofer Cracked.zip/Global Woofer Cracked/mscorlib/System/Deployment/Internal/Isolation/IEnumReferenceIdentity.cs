﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000666 RID: 1638
	[Guid("b30352cf-23da-4577-9b3f-b4e6573be53b")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[ComImport]
	internal interface IEnumReferenceIdentity
	{
		// Token: 0x06004E69 RID: 20073
		[SecurityCritical]
		uint Next([In] uint celt, [MarshalAs(UnmanagedType.LPArray)] [Out] IReferenceIdentity[] ReferenceIdentity);

		// Token: 0x06004E6A RID: 20074
		[SecurityCritical]
		void Skip(uint celt);

		// Token: 0x06004E6B RID: 20075
		[SecurityCritical]
		void Reset();

		// Token: 0x06004E6C RID: 20076
		[SecurityCritical]
		IEnumReferenceIdentity Clone();
	}
}
