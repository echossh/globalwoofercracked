﻿using System;
using System.Collections;
using System.Security;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000657 RID: 1623
	internal class StoreDeploymentMetadataPropertyEnumeration : IEnumerator
	{
		// Token: 0x06004E1A RID: 19994 RVA: 0x001179B0 File Offset: 0x00115BB0
		public StoreDeploymentMetadataPropertyEnumeration(IEnumSTORE_DEPLOYMENT_METADATA_PROPERTY pI)
		{
			this._enum = pI;
		}

		// Token: 0x06004E1B RID: 19995 RVA: 0x001179BF File Offset: 0x00115BBF
		private StoreOperationMetadataProperty GetCurrent()
		{
			if (!this._fValid)
			{
				throw new InvalidOperationException();
			}
			return this._current;
		}

		// Token: 0x17000C88 RID: 3208
		// (get) Token: 0x06004E1C RID: 19996 RVA: 0x001179D5 File Offset: 0x00115BD5
		object IEnumerator.Current
		{
			get
			{
				return this.GetCurrent();
			}
		}

		// Token: 0x17000C89 RID: 3209
		// (get) Token: 0x06004E1D RID: 19997 RVA: 0x001179E2 File Offset: 0x00115BE2
		public StoreOperationMetadataProperty Current
		{
			get
			{
				return this.GetCurrent();
			}
		}

		// Token: 0x06004E1E RID: 19998 RVA: 0x001179EA File Offset: 0x00115BEA
		public IEnumerator GetEnumerator()
		{
			return this;
		}

		// Token: 0x06004E1F RID: 19999 RVA: 0x001179F0 File Offset: 0x00115BF0
		[SecuritySafeCritical]
		public bool MoveNext()
		{
			StoreOperationMetadataProperty[] array = new StoreOperationMetadataProperty[1];
			uint num = this._enum.Next(1U, array);
			if (num == 1U)
			{
				this._current = array[0];
			}
			return this._fValid = (num == 1U);
		}

		// Token: 0x06004E20 RID: 20000 RVA: 0x00117A30 File Offset: 0x00115C30
		[SecuritySafeCritical]
		public void Reset()
		{
			this._fValid = false;
			this._enum.Reset();
		}

		// Token: 0x04002143 RID: 8515
		private IEnumSTORE_DEPLOYMENT_METADATA_PROPERTY _enum;

		// Token: 0x04002144 RID: 8516
		private bool _fValid;

		// Token: 0x04002145 RID: 8517
		private StoreOperationMetadataProperty _current;
	}
}
