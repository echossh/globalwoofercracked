﻿using System;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000669 RID: 1641
	internal enum IIDENTITYAUTHORITY_DEFINITION_IDENTITY_TO_TEXT_FLAGS
	{
		// Token: 0x04002156 RID: 8534
		IIDENTITYAUTHORITY_DEFINITION_IDENTITY_TO_TEXT_FLAG_CANONICAL = 1
	}
}
