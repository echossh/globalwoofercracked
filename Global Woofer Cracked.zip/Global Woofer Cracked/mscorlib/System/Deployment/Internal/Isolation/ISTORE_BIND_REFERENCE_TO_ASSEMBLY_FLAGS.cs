﻿using System;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000670 RID: 1648
	[Flags]
	internal enum ISTORE_BIND_REFERENCE_TO_ASSEMBLY_FLAGS
	{
		// Token: 0x04002160 RID: 8544
		ISTORE_BIND_REFERENCE_TO_ASSEMBLY_FLAG_FORCE_LIBRARY_SEMANTICS = 1
	}
}
