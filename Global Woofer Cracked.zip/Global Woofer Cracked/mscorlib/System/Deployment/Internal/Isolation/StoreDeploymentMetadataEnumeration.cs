﻿using System;
using System.Collections;
using System.Security;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000655 RID: 1621
	internal class StoreDeploymentMetadataEnumeration : IEnumerator
	{
		// Token: 0x06004E0F RID: 19983 RVA: 0x00117925 File Offset: 0x00115B25
		public StoreDeploymentMetadataEnumeration(IEnumSTORE_DEPLOYMENT_METADATA pI)
		{
			this._enum = pI;
		}

		// Token: 0x06004E10 RID: 19984 RVA: 0x00117934 File Offset: 0x00115B34
		private IDefinitionAppId GetCurrent()
		{
			if (!this._fValid)
			{
				throw new InvalidOperationException();
			}
			return this._current;
		}

		// Token: 0x17000C86 RID: 3206
		// (get) Token: 0x06004E11 RID: 19985 RVA: 0x0011794A File Offset: 0x00115B4A
		object IEnumerator.Current
		{
			get
			{
				return this.GetCurrent();
			}
		}

		// Token: 0x17000C87 RID: 3207
		// (get) Token: 0x06004E12 RID: 19986 RVA: 0x00117952 File Offset: 0x00115B52
		public IDefinitionAppId Current
		{
			get
			{
				return this.GetCurrent();
			}
		}

		// Token: 0x06004E13 RID: 19987 RVA: 0x0011795A File Offset: 0x00115B5A
		public IEnumerator GetEnumerator()
		{
			return this;
		}

		// Token: 0x06004E14 RID: 19988 RVA: 0x00117960 File Offset: 0x00115B60
		[SecuritySafeCritical]
		public bool MoveNext()
		{
			IDefinitionAppId[] array = new IDefinitionAppId[1];
			uint num = this._enum.Next(1U, array);
			if (num == 1U)
			{
				this._current = array[0];
			}
			return this._fValid = (num == 1U);
		}

		// Token: 0x06004E15 RID: 19989 RVA: 0x0011799C File Offset: 0x00115B9C
		[SecuritySafeCritical]
		public void Reset()
		{
			this._fValid = false;
			this._enum.Reset();
		}

		// Token: 0x04002140 RID: 8512
		private IEnumSTORE_DEPLOYMENT_METADATA _enum;

		// Token: 0x04002141 RID: 8513
		private bool _fValid;

		// Token: 0x04002142 RID: 8514
		private IDefinitionAppId _current;
	}
}
