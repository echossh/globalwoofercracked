﻿using System;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x0200066D RID: 1645
	[Flags]
	internal enum IAPPIDAUTHORITY_ARE_DEFINITIONS_EQUAL_FLAGS
	{
		// Token: 0x0400215C RID: 8540
		IAPPIDAUTHORITY_ARE_DEFINITIONS_EQUAL_FLAG_IGNORE_VERSION = 1
	}
}
