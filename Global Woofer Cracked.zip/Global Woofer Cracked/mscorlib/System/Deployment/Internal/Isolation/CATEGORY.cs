﻿using System;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000650 RID: 1616
	internal struct CATEGORY
	{
		// Token: 0x0400213C RID: 8508
		public IDefinitionIdentity DefinitionIdentity;
	}
}
