﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x02000664 RID: 1636
	[Guid("9cdaae75-246e-4b00-a26d-b9aec137a3eb")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[ComImport]
	internal interface IEnumIDENTITY_ATTRIBUTE
	{
		// Token: 0x06004E60 RID: 20064
		[SecurityCritical]
		uint Next([In] uint celt, [MarshalAs(UnmanagedType.LPArray)] [Out] IDENTITY_ATTRIBUTE[] rgAttributes);

		// Token: 0x06004E61 RID: 20065
		[SecurityCritical]
		IntPtr CurrentIntoBuffer([In] IntPtr Available, [MarshalAs(UnmanagedType.LPArray)] [Out] byte[] Data);

		// Token: 0x06004E62 RID: 20066
		[SecurityCritical]
		void Skip([In] uint celt);

		// Token: 0x06004E63 RID: 20067
		[SecurityCritical]
		void Reset();

		// Token: 0x06004E64 RID: 20068
		[SecurityCritical]
		IEnumIDENTITY_ATTRIBUTE Clone();
	}
}
