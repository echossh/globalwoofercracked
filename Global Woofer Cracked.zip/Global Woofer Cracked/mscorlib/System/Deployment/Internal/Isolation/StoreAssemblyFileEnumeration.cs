﻿using System;
using System.Collections;
using System.Security;

namespace System.Deployment.Internal.Isolation
{
	// Token: 0x0200065B RID: 1627
	internal class StoreAssemblyFileEnumeration : IEnumerator
	{
		// Token: 0x06004E30 RID: 20016 RVA: 0x00117AD8 File Offset: 0x00115CD8
		public StoreAssemblyFileEnumeration(IEnumSTORE_ASSEMBLY_FILE pI)
		{
			this._enum = pI;
		}

		// Token: 0x06004E31 RID: 20017 RVA: 0x00117AE7 File Offset: 0x00115CE7
		public IEnumerator GetEnumerator()
		{
			return this;
		}

		// Token: 0x06004E32 RID: 20018 RVA: 0x00117AEA File Offset: 0x00115CEA
		private STORE_ASSEMBLY_FILE GetCurrent()
		{
			if (!this._fValid)
			{
				throw new InvalidOperationException();
			}
			return this._current;
		}

		// Token: 0x17000C8C RID: 3212
		// (get) Token: 0x06004E33 RID: 20019 RVA: 0x00117B00 File Offset: 0x00115D00
		object IEnumerator.Current
		{
			get
			{
				return this.GetCurrent();
			}
		}

		// Token: 0x17000C8D RID: 3213
		// (get) Token: 0x06004E34 RID: 20020 RVA: 0x00117B0D File Offset: 0x00115D0D
		public STORE_ASSEMBLY_FILE Current
		{
			get
			{
				return this.GetCurrent();
			}
		}

		// Token: 0x06004E35 RID: 20021 RVA: 0x00117B18 File Offset: 0x00115D18
		[SecuritySafeCritical]
		public bool MoveNext()
		{
			STORE_ASSEMBLY_FILE[] array = new STORE_ASSEMBLY_FILE[1];
			uint num = this._enum.Next(1U, array);
			if (num == 1U)
			{
				this._current = array[0];
			}
			return this._fValid = (num == 1U);
		}

		// Token: 0x06004E36 RID: 20022 RVA: 0x00117B58 File Offset: 0x00115D58
		[SecuritySafeCritical]
		public void Reset()
		{
			this._fValid = false;
			this._enum.Reset();
		}

		// Token: 0x04002149 RID: 8521
		private IEnumSTORE_ASSEMBLY_FILE _enum;

		// Token: 0x0400214A RID: 8522
		private bool _fValid;

		// Token: 0x0400214B RID: 8523
		private STORE_ASSEMBLY_FILE _current;
	}
}
