﻿using System;

namespace System
{
	// Token: 0x02000169 RID: 361
	internal struct DateTimeToken
	{
		// Token: 0x04000777 RID: 1911
		internal DateTimeParse.DTT dtt;

		// Token: 0x04000778 RID: 1912
		internal TokenType suffix;

		// Token: 0x04000779 RID: 1913
		internal int num;
	}
}
