﻿using System;

namespace System
{
	// Token: 0x02000129 RID: 297
	// (Invoke) Token: 0x06001105 RID: 4357
	internal delegate void CtorDelegate(object instance);
}
