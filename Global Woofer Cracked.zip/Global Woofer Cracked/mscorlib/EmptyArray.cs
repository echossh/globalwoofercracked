﻿using System;

// Token: 0x02000003 RID: 3
internal static class EmptyArray<T>
{
	// Token: 0x04000002 RID: 2
	public static readonly T[] Value = new T[0];
}
